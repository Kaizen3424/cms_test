/**
 * Vite build for the admin SPA (D2 stack). Workspace packages are consumed
 * AS SOURCE (gotcha: `resolve.dedupe` React; internal exports resolve to src).
 * Prod purity: no sourcemaps in the shipped artifact (INV-N04 scan).
 */
declare const _default: import("vite").UserConfig;
export default _default;

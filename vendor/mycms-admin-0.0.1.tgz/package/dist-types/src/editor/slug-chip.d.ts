export interface SlugChipProps {
    readonly isNew: boolean;
    readonly collection: string;
    readonly slug: string;
    readonly onSlugChange?: (nextSlug: string) => void;
    readonly existingSlugs?: readonly string[];
    readonly supportName?: string;
    readonly entryTitle?: string;
}
export declare function SlugChip({ isNew, collection, slug, onSlugChange, existingSlugs, supportName, entryTitle, }: SlugChipProps): import("react").JSX.Element;
export declare function sanitizeSlugInput(input: string): string;
export declare function deriveSlugFromTitle(title: string, existingSlugs?: readonly string[]): string;

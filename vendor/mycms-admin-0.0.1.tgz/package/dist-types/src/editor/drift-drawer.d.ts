import type { DriftInfo } from "./drift-monitor";
export interface DriftDrawerProps {
    readonly open: boolean;
    readonly onOpenChange: (open: boolean) => void;
    readonly drift?: DriftInfo;
    readonly supportName: string;
    readonly isDirty: boolean;
    readonly onReload: () => void;
}
export declare function DriftDrawer({ open, onOpenChange, drift, supportName, isDirty, onReload, }: DriftDrawerProps): import("react").JSX.Element | null;

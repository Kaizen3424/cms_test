/**
 * Entry form model (P2.6) — the value-domain half of the editor. Pure, no
 * React, no transport, no second serializer.
 *
 * The held tree is the FULL value: modeled fields + unmodeled keys merged by
 * `composeEntryDocument()` with virtual `slug` fields stripped. That single
 * choice keeps three laws true at once:
 *  - `rebase()` never sees an untouched key as deleted (no silent data loss);
 *  - a stale `slug` key in the source file never shows as a phantom edit;
 *  - the bytes written are exactly `composeEntryDocument(...)` (one composer).
 *
 * Dirtiness is recomputed from the value domain on every edit
 * (`computeDirtyPaths`), never from the machine phase (ADR-0004 P2.6 pin).
 */
import type { FieldDescriptor, FieldPath, JsonDocument } from "@mycms/core";
import type { IndexedEntry } from "../runtime/entry-index";
export interface EntryFormState {
    /** Full edited tree (untouched keys merged, virtual fields stripped). */
    readonly formValue: Readonly<Record<string, unknown>>;
    /** The commit the form was loaded against — the CAS coordinate. */
    readonly baseSha: string;
    /** Raw bytes of that commit (rebase's `oldRaw`). */
    readonly baseRaw: string;
    /** Parsed `baseRaw` in the composed (slug-stripped) shape. */
    readonly baseValue: Readonly<Record<string, unknown>>;
    /** Source document — keeps original bytes/newlines for unchanged saves. */
    readonly document: JsonDocument;
    readonly dirtyPaths: readonly FieldPath[];
}
export type EntryFormInit = {
    readonly ok: true;
    readonly form: EntryFormState;
} | {
    readonly ok: false;
    readonly reason: "unreadable";
};
/**
 * Seeds the form from an indexed entry. Unreadable source JSON is refused:
 * editing it would mean re-printing bytes we never parsed (INV-S01).
 */
export declare function createEntryForm(entry: IndexedEntry, baseSha: string): EntryFormInit;
/** One keystroke: immutable set (`undefined` removes the key). */
export declare function withFieldValue(form: EntryFormState, name: string, value: unknown): EntryFormState;
/** True when the local tree differs from the base — the bar's only dirty input. */
export declare function isFormDirty(form: EntryFormState): boolean;
/** The bytes this save would write (single composer; no admin-side serialization). */
export declare function composeFormBytes(form: EntryFormState, fields: readonly FieldDescriptor[]): string;
/**
 * Post-publish base refresh (ADR-0004 P2.6 pin): the new coordinate is the
 * commit the ref was OBSERVED carrying (`verdict.commitSha`) and the bytes we
 * composed — never a re-read. Edits typed during the save survive and are
 * re-diffed against the new base, so no keystroke is discarded.
 */
export declare function withPublishedBase(form: EntryFormState, input: {
    readonly commitSha: string;
    readonly raw: string;
}): EntryFormState;
/**
 * Adopts a reconciled base (P2.9 — ADR-0004 auto-merge base adoption).
 * The base is updated to <commitSha, reconciledRaw>. Keystrokes typed while
 * the save ran (the difference between the live form and the submit snapshot)
 * are replayed onto the reconciled base tree.
 */
export declare function withReconciledBase(form: EntryFormState, input: {
    readonly commitSha: string;
    readonly raw: string;
    readonly submitSnapshot: Readonly<Record<string, unknown>>;
}): EntryFormState;
/** "Start over from the latest version": drop the local tree, keep the base. */
export declare function withLatestVersion(form: EntryFormState): EntryFormState;
/** Replaces the edited tree (boot restore / merged replay bytes). */
export declare function withFieldTree(form: EntryFormState, tree: Readonly<Record<string, unknown>>): EntryFormState;
/**
 * Rebinds the base (boot replay's FRESH head, lease steal, manual refresh).
 * The local tree is preserved and re-diffed, so nothing typed is lost.
 */
export declare function withBase(form: EntryFormState, input: {
    readonly baseSha: string;
    readonly baseRaw: string;
}): EntryFormState;

import type { SweepVerdict } from "./save-sweep";
export interface AdvisoryChipsProps {
    readonly verdict: SweepVerdict | undefined;
    readonly supportName: string;
}
export declare function AdvisoryChips({ verdict, supportName }: AdvisoryChipsProps): import("react").JSX.Element | null;

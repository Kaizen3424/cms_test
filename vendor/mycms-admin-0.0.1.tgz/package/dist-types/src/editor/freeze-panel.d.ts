/**
 * Freeze panel (P2.9 — ADR-0004 P2.9 appendix).
 *
 * Renders the field-granularity conflict decisions above the field grid:
 *  - One row per frozen field path comparing "The other version" vs "Your version".
 *  - Remote values rendered strictly as plain text nodes (ADR-0006 trust policy).
 *  - Escape hatch "Start over from the latest version" available on both normal
 *    and degraded branches.
 */
import type { FieldPath } from "@mycms/core";
import type { FreezeRow } from "./freeze-model";
export interface FreezePanelProps {
    readonly rows?: readonly FreezeRow[];
    readonly ourFieldPaths?: readonly FieldPath[];
    readonly mergeWarnings?: readonly FieldPath[];
    readonly onChoose?: (path: FieldPath, choice: "theirs" | "mine") => void;
    readonly onStartOver: () => void;
    readonly degraded?: boolean;
    readonly supportName: string;
}
export declare function FreezePanel({ rows, ourFieldPaths, mergeWarnings, onChoose, onStartOver, degraded, supportName, }: FreezePanelProps): import("react").JSX.Element;

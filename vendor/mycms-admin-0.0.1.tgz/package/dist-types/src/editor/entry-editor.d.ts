/**
 * Entry editor v0 (P2.6) — one screen, one serializer, one machine.
 *
 * Laws this component enforces (ADR-0004 P2.6 pins):
 *  - the ONLY bytes it writes come from `composeFormBytes` → `composeEntryDocument`;
 *  - the draft is written pre-network by the coordinator and by a debounce here
 *    (crash protection), never as an autosave of content;
 *  - a boot replay only ADJUDICATES: nothing touches the remote until the
 *    founder confirms, and a conflict offers "start over", never a silent write;
 *  - the machine is reset on mount and after every published verdict, so a
 *    second save in the same session is possible;
 *  - edits typed while a save is committing survive and re-dirty the form.
 */
import type { FieldDescriptor } from "@mycms/core";
import type { ReactNode } from "react";
import type { EntryIndex, IndexedEntry } from "../runtime/entry-index";
export interface EntryEditorProps {
    readonly entry: IndexedEntry;
    /** Snapshot head commit — the base the form loads against. */
    readonly headSha: string;
    /** Whole-repo index for relation existence checks (strict save gate). */
    readonly index: EntryIndex | undefined;
    /** Read-only renderer for list/object/image/relation/slug/hidden fields. */
    readonly renderReadOnly: (field: FieldDescriptor, value: unknown) => ReactNode;
    readonly isNew?: boolean;
    readonly onCreated?: (collectionName: string, slug: string) => void;
}
export declare function EntryEditor({ entry, headSha, index, renderReadOnly, isNew, onCreated, }: EntryEditorProps): import("react").JSX.Element;

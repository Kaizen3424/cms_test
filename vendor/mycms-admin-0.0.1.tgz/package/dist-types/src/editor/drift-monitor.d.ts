import type { GitBackend } from "@mycms/core";
export interface DriftInfo {
    readonly remoteSha: string;
    readonly detectedAt: string;
}
export interface UseDriftMonitorOptions {
    readonly branch?: string;
    readonly baseHeadSha?: string;
    readonly entryPath?: string;
    readonly backend?: GitBackend;
    readonly rateLimitRemaining?: number | null;
    readonly enabled?: boolean;
    readonly pollIntervalMs?: number;
    readonly idleBackoffMs?: number;
}
export declare function useDriftMonitor(options: UseDriftMonitorOptions): {
    readonly drift: DriftInfo | undefined;
    readonly clearDrift: () => void;
};

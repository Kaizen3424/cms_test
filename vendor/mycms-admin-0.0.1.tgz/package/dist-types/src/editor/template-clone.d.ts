import type { FieldDescriptor, FolderCollectionDescriptor } from "@mycms/core";
import type { IndexedEntry } from "../runtime/entry-index";
/**
 * Clones an existing entry as a template for a new entry.
 *
 * Laws (P3.7 & ADR-0003 P3 Addendum):
 *  - Strips identity: title and slug are cleared.
 *  - Retains all structure: choice-tabs, specs, accordions, categories.
 *  - Shares media by reference: no asset duplication.
 *  - Leaf-first default fold: materializes defaults for any declared field missing from source.
 *  - Prefills required lists: ensures lists with `min >= 1` have valid starter items.
 */
export declare function cloneEntryAsTemplate(sourceEntry: IndexedEntry, collection: FolderCollectionDescriptor): Record<string, unknown>;
/**
 * Creates initial form values for a blank entry in a collection.
 */
export declare function createNewBlankEntry(collection: FolderCollectionDescriptor): Record<string, unknown>;
/**
 * Walks collection fields leaf-first to populate default values and ensure
 * required lists (min >= 1) are pre-populated with valid default items.
 */
export declare function foldFieldDefaults(fields: readonly FieldDescriptor[], target: Record<string, unknown>): void;
/**
 * Creates a synthetic `IndexedEntry` representing a new uncommitted entry.
 */
export declare function createSyntheticNewIndexedEntry(collection: FolderCollectionDescriptor, slug: string, initialValue?: Record<string, unknown>): IndexedEntry;

/**
 * Founder-facing copy deck (P2.6). This module owns every save/recovery string;
 * `status/copy.ts` owns the deploy-status strings (P2.8), and `copy.test.ts`
 * sweeps both decks with ONE banned-word scan (01-spec §6: no "build",
 * "commit", "deploy", "token", "slug", "repository", "draft", "someone",
 * "conflict").
 *
 * Rules encoded here:
 *  - the named human always comes from `support.name` via `{name}` — never
 *    "someone" (master-plan §7);
 *  - "access key" is the only word for the credential;
 *  - every line says what happened, what is safe, and what to do next.
 */
export type SaveBarStatus = "clean" | "dirty" | "saving" | "saved" | "noop" | "conflict" | "busy" | "paused" | "authExpired" | "failed" | "leaseLost";
export interface CopyLine {
    readonly title: string;
    readonly detail?: string;
}
/** The 11 sticky-bar states (P2.6 scope). */
export declare const SAVE_BAR_COPY: Readonly<Record<SaveBarStatus, CopyLine>>;
/** Recovery surfaces P2.6 ships (boot offer, start-over, retry, discard) + the P2.7 lease re-check. */ export declare const RECOVERY_COPY: {
    readonly restoreFound: {
        readonly title: "We found unsaved changes on this device.";
        readonly detail: "They were never published. Restore them here?";
        readonly confirm: "Restore changes";
        readonly dismiss: "Keep them for later";
    };
    readonly startOver: {
        readonly label: "Start over from the latest version";
        readonly detail: "Your unsaved changes on this device will be removed.";
    };
    readonly discardLocal: {
        readonly label: "Discard the changes kept on this device";
        readonly detail: "They will not be published. This cannot be undone here.";
    };
    readonly retrySave: {
        readonly label: "Try saving again";
        readonly detail: "Nothing is lost by trying again.";
    };
    readonly recheck: {
        readonly label: "Check again";
        readonly detail: "Nothing is lost by checking. Saving unlocks once your other tab is closed.";
    };
};
/** Validation gate — the save button refused locally (no network attempt). */
export declare const VALIDATION_COPY: {
    readonly blockedTitle: "Some fields need attention.";
    readonly blockedDetail: "Fix the highlighted fields, then save again.";
};
/**
 * Post-publish advisory chips (P2.7 — ADR-0004 P2.7 pins). The master-plan
 * §5.2 wording used the banned "committed"; the deck says "saved" (superseding
 * note is pinned in the ADR). These lines NEVER gate a save.
 */
export declare const ADVISORY_COPY: {
    readonly pausedTitle: "Your change is saved, but the site's update is paused by an older problem.";
    readonly chipDetail: "{title}: {detail}";
    readonly takeMeThere: "Take me there";
    readonly copyMessage: "Copy message for {name}";
    readonly copyBody: "{title}: {detail} ({path})";
    readonly copied: "Copied";
    readonly dismiss: "Dismiss";
    readonly unknownTitle: "We could not check the rest of the site just now.";
    readonly unknownDetail: "Your change is saved. Tell {name} if it does not appear live within a few minutes.";
};
/**
 * Conflict freeze region copy (P2.9 — ADR-0004 appendix).
 * "conflict" is banned — the surface says "this entry changed somewhere else",
 * "the other version".
 */
export declare const FREEZE_COPY: {
    readonly title: "This entry changed somewhere else.";
    readonly detail: "Decide which version to keep for each field before saving.";
    readonly otherEditsKept: "Your other edits are kept.";
    readonly theirsHeader: "The other version";
    readonly mineHeader: "Your version";
    readonly keepTheirs: "Keep the other version";
    readonly keepMine: "Keep my version";
    readonly startOver: "Start over from the latest version";
    readonly degradedTitle: "This entry changed somewhere else.";
    readonly degradedDetail: "Your words are safe on this device. Start over from the latest version to load the latest changes.";
    readonly savedByHeader: "Saved by {name}";
    readonly yourVersionHeader: "Your version (edited on this device)";
    readonly keptYourField: "Kept your {field}";
    readonly keptPartnerField: "Kept {name}'s {field}";
    readonly copyDiscarded: "Copy discarded version";
    readonly copiedDiscarded: "Discarded text copied to clipboard";
};
/** Bar buttons — same banned-word sweep as the status lines. */
export declare const ACTION_COPY: {
    readonly save: "Save changes";
    readonly saving: "Saving...";
    readonly retry: "Try saving again";
    readonly startOver: "Start over from the latest version";
    readonly signOut: "Sign out";
};
/**
 * Failure card copy (P2.10 — INV-A02 classifier matrix).
 * Rendered docked above the SaveBar on non-quota failures and on entry read errors.
 * No banned words; "{name}" comes from config support.name.
 */
export declare const FAILURE_COPY: Readonly<Record<string, CopyLine>>;
/** In-place re-auth modal copy (P2.10 — INV-A01). */
export declare const REAUTH_COPY: {
    readonly title: "Your access key needs checking";
    readonly detail: "Your changes are safe on this device. Enter your access key to continue saving.";
    readonly readTitle: "Your access key needs checking to open this entry.";
    readonly inputLabel: "Access key";
    readonly inputPlaceholder: "Paste your access key here";
    readonly showKey: "Show access key";
    readonly hideKey: "Hide access key";
    readonly remember: "Remember on this device";
    readonly submit: "Check key and save";
    readonly submitRead: "Check key";
    readonly submitting: "Checking key...";
    readonly cancel: "Keep editing";
    readonly signOut: "Sign out";
    readonly errorInvalid: "This access key could not be verified. Check the key and its permissions.";
    readonly errorEmpty: "Please enter your access key.";
};
/** Rate limit reset countdown copy (P2.10 — INV-N01). */
export declare const RATE_COPY: {
    readonly busyTitle: "The site is busy right now.";
    readonly countdown: "Resuming in {seconds} seconds...";
    readonly pausedTitle: "Saving is paused.";
    readonly pausedDetail: "Your changes are kept on this device. Try saving again in a moment.";
    readonly resumeNow: "Try saving now";
    readonly announcementStart: "Saving is paused because the site is busy. Resuming in about {seconds} seconds.";
    readonly announcementWarning: "Resuming in 10 seconds.";
    readonly announcementResume: "Resuming now.";
};
/** Failure card actions and labels (P2.10). */
export declare const FAILURE_CARD_COPY: {
    readonly reassurance: "Your changes are kept on this device.";
    readonly retry: "Try saving again";
    readonly checkKey: "Check access key";
    readonly copyMessage: "Copy message for {name}";
    readonly copied: "Copied to clipboard";
    readonly technicalDetails: "Technical details for {name}";
    readonly startOver: "Start over from the latest version";
};
/** Entry screen read failure actions (P2.10). */
export declare const READ_ERROR_COPY: {
    readonly retry: "Try loading again";
    readonly backToFolder: "Back to folder";
    readonly copyMessage: "Copy message for {name}";
};
/** Web address lifecycle copy (P3.5). */
export declare const SLUG_COPY: {
    readonly webAddress: "web address:";
    readonly fixableUntilSave: "— still fixable until Save";
    readonly changeInfo: "Need to change this?";
    readonly closeInfo: "Close info";
    readonly lockedExplanation: "This web address is already live. Changing it directly could break bookmarks or links from other websites. To keep your visitors happy, address changes are best handled with an automatic redirect.";
    readonly copyNote: "Copy note for {name}";
    readonly copied: "Copied note to clipboard!";
    readonly collision: "An address with this name already exists. We recommend choosing a distinct name before saving.";
};
/** Template and new-entry flow copy (P3.7). */
export declare const TEMPLATE_COPY: {
    readonly newEntry: "New entry";
    readonly startFromBlank: "Start from blank";
    readonly startFromTemplate: "Start from an existing item";
    readonly nothingPublished: "Nothing published until you Save";
    readonly creatingNew: "Creating new entry";
};
/** Behind-the-scenes drawer copy (P3.4). */
export declare const BEHIND_THE_SCENES_COPY: {
    readonly title: "Behind the scenes — managed by {name}";
    readonly description: "These settings work quietly behind the scenes to keep your website looking sharp.";
    readonly notShown: "Not shown on your site right now";
};
/** Media library and image handling copy (P4.6). */
export declare const MEDIA_COPY: {
    readonly title: "Media Library";
    readonly searchPlaceholder: "Search images by name or path...";
    readonly filterAll: "All";
    readonly emptyState: "No images found.";
    readonly emptySearch: "No images match your search.";
    readonly uploadButton: "Upload image";
    readonly uploadPrompt: "Drag & drop an image or browse";
    readonly uploading: "Optimizing image...";
    readonly retryUpload: "Retry upload";
    readonly chooseFromLibrary: "Choose from library";
    readonly detailsTitle: "Image Details";
    readonly publicPath: "Public path";
    readonly copyPath: "Copy path";
    readonly copied: "Copied!";
    readonly dimensions: "Dimensions";
    readonly fileSize: "File size";
    readonly usedIn: "Used in";
    readonly noReferences: "Not used in any entries yet.";
    readonly altPrefillPrefix: "Last used as:";
    readonly replaceTitle: "Replace image file";
    readonly replaceWarning: "Replacing an existing file keeps the same web address. Because public sites cache images, visitors may see the old image for up to 1 hour.";
    readonly deleteButton: "Delete image";
    readonly deleteWarning: "This will remove the image from the site. If it is used in any entries, it cannot be deleted until those references are removed.";
    readonly budgetWarning: "Your media storage is reaching recommended limits. Ask {name} to archive older images to keep everything fast.";
};
/** Recently deleted / tombstone copy (P4.7). */
export declare const TRASH_COPY: {
    readonly title: "Recently Deleted";
    readonly subtitle: "Restoring moves the image back to its original location. Entries that previously used it will need to be re-saved if their fields were cleared.";
    readonly emptyState: "No recently deleted images.";
    readonly restoreButton: "Restore";
    readonly restoring: "Restoring...";
    readonly restored: "Restored!";
    readonly collisionError: "Cannot restore: an image already exists at the original location.";
    readonly deleteBlocked: "Cannot delete: this image is used in entries.";
    readonly confirmDelete: "Move this image to Recently Deleted?";
};
/** Global search copy (P5.1). */
export declare const SEARCH_COPY: {
    readonly placeholder: "Search titles, numbers, materials, or photo descriptions...";
    readonly promptTitle: "Find anything on your site";
    readonly promptDetail: "Search products, collections, and pages by title, price, material, or photo description...";
    readonly emptyTitle: "No matches found";
    readonly emptyDetail: 'No entries match "{query}". Try searching whole-euro prices (e.g. 1450), materials, or title words.';
    readonly offlineBadge: "Showing last-seen copy";
    readonly shortcuts: "↑↓ to navigate · ↵ to open · esc to close";
};
/** Activity journal copy (P5.2). */
export declare const JOURNAL_COPY: {
    readonly title: "Activity journal";
    readonly subtitle: "Recent changes saved to this site.";
    readonly myChanges: "My changes";
    readonly partnerChanges: "Site updates by {name}";
    readonly emptyMyChanges: "You have not saved any changes yet on this device.";
    readonly emptyPartnerChanges: "No recent updates from {name}.";
    readonly seeOnSite: "See on site";
    readonly savedAt: "Saved {time}";
    readonly close: "Close journal";
};
/** Ambient heartbeat copy (P5.2). */
export declare const HEARTBEAT_COPY: {
    readonly liveTitle: "Site live";
    readonly lastEditYours: "Site live · Last edit yours, {time}";
    readonly lastEditPartner: "Site live · Last edit {name}, {time}";
    readonly updating: "Site updating...";
    readonly loginConnected: "Connected to site content";
    readonly loginLastSeen: "Last connected {time}";
};
/** Onboarding consent pact and 60-second tour copy (P5.3). */
export declare const ONBOARDING_COPY: {
    readonly pactTitle: "Welcome to your content studio";
    readonly pactSentence1: "You are connected to this site's live content.";
    readonly pactSentence2: "Changes you make only publish when you choose to save them.";
    readonly pactSentence3: "Your edits are kept safe on this device while you work.";
    readonly takeTour: "Take a 60-second tour";
    readonly dismiss: "Dismiss";
    readonly tourTitle: "How this studio works";
    readonly stepOf: "Step {current} of {total}";
    readonly close: "Close tour";
    readonly next: "Next";
    readonly back: "Back";
    readonly finish: "Finish tour";
    readonly step1Title: "Clear, simple fields";
    readonly step1Body: "Every field is checked as you type, keeping everything clean and in order.";
    readonly step2Title: "You are in control";
    readonly step2Body: "Changes stay on your device until you choose to save. Nothing goes live without your say-so.";
    readonly step3Title: "Special settings when needed";
    readonly step3Body: "Advanced settings stay quietly tucked away behind the scenes so you can focus on writing.";
    readonly step4Title: "Ambient confidence";
    readonly step4Body: "A heartbeat indicator lets you know your public site is up to date.";
};
/** Background drift monitor copy (P5.4). */
export declare const DRIFT_COPY: {
    readonly bannerTitle: "This page's files changed ({name}, {time})";
    readonly whatChanged: "What changed?";
    readonly drawerTitle: "Updates detected on the site";
    readonly drawerSubtitle: "Saved by {name} · {time}";
    readonly keepEditingTitle: "Keep editing";
    readonly keepEditingBody: "Your changes remain safe on this device. When you save, any differences will be presented clearly before saving.";
    readonly reloadLatest: "Reload latest version";
    readonly reloadWarning: "Reloading will replace what is on this screen.";
    readonly close: "Close updates panel";
};
/** Token expiry proactive and recovery copy (P5.7). */
export declare const EXPIRY_COPY: {
    readonly renewChip: "Renew after {date}";
    readonly renewNotice: "Access key renewal coming up after {date} — ask {name} for a fresh code";
    readonly reauthPreserved: "Your access key needs checking. Your changes are kept safe on this device — enter a fresh access key to resume without losing anything.";
    readonly partnerNoteButton: "Copy note for {name}";
    readonly partnerNoteText: "Hi {name}, my studio access key for the website has expired. Could you generate a fresh access key for me?";
    readonly copiedNote: "Note copied to clipboard";
    readonly handoverTitle: "Access key renewal";
    readonly handoverSubtitle: "Set when your access key was created and how long it lasts.";
    readonly createdLabel: "Key created date";
    readonly durationLabel: "Duration";
    readonly saveSettings: "Save settings";
    readonly settingsSaved: "Saved";
};
/** Studio diagnostics copy (P5.10). */
export declare const DIAGNOSTICS_COPY: {
    readonly title: "Studio diagnostics";
    readonly subtitle: "Technical details from this session. Access keys and personal emails are always hidden.";
    readonly empty: "No diagnostics recorded in this session yet.";
    readonly copyButton: "Copy diagnostics";
    readonly copiedSuccess: "Diagnostics copied to clipboard. You can paste this to {name}.";
    readonly close: "Close";
    readonly systemLabel: "Studio information";
};
/** Substitutes `{name}` with the named human from `support.name`. */
export declare function fillName(template: string, name: string): string;
/**
 * Generic placeholder fill for chip lines ({title}/{detail}/{count}). Built on
 * split/join, never String.replace — a value containing `$` patterns must be
 * inert (validator copy comes from repo content).
 */
export declare function fillLine(template: string, values: Readonly<Record<string, string>>): string;
/** Applies `fillName` to every field of a copy line (detail may carry `{name}`). */
export declare function personalize(line: CopyLine, name: string): CopyLine;
/**
 * Every user-visible string in this module — the banned-word test walks this
 * (recursively derived so a new line cannot dodge the sweep).
 */
export declare function allCopyStrings(): readonly string[];

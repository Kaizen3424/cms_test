/**
 * Structured Copy Composer (P2.10 — master-plan §2.8 & §7).
 *
 * Emits a dual-audience diagnostic message:
 *  1. Plain human greeting from founder to {support.name} (no jargon, friendly SVO).
 *  2. Structured bulleted diagnostics for the technical partner (entry, repo, branch,
 *     base revision, changed fields, typed error code, HTTP status, timestamp, and guidance).
 *
 * Guarantees zero credential leaks (INV-A04/INV-A05): tokens and raw request bodies
 * are NEVER accepted or printed.
 */
export interface FailureReportContext {
    readonly entryTitle: string;
    readonly filePath: string;
    readonly branch: string;
    readonly repo: string;
    readonly baseSha: string;
    readonly changedFields?: readonly string[];
    readonly errorCode: string;
    readonly httpStatus?: number;
    readonly timestamp: string;
    readonly partnerName: string;
    readonly guidance?: string;
    readonly kind?: "save" | "read" | "advisory";
    readonly advisoryDetail?: string;
}
export declare const PARTNER_GUIDANCE: Readonly<Record<string, string>>;
/** Formats the dual-audience diagnostic payload for sharing with support.name. */
export declare function composeFailureReport(ctx: FailureReportContext): string;
/**
 * Copies plain text to the clipboard via navigator.clipboard.writeText, falling back
 * to a hidden textarea execCommand in headless or unprivileged browser frames.
 */
export declare function copyToClipboard(text: string): Promise<boolean>;

export interface FailureCardTechnicalContext {
    readonly entryTitle: string;
    readonly filePath: string;
    readonly branch: string;
    readonly repo: string;
    readonly baseSha: string;
    readonly changedFields?: readonly string[];
}
export interface FailureCardProps {
    readonly errorCode: string;
    readonly httpStatus?: number;
    readonly supportName: string;
    readonly onRetry?: () => void;
    readonly onCheckKey?: () => void;
    readonly onStartOver?: () => void;
    readonly onCopyMessage: () => void;
    readonly copied: boolean;
    readonly technicalContext?: FailureCardTechnicalContext;
}
/**
 * Docked failure card (P2.10 — INV-A02 classifier matrix).
 * Renders directly above the sticky SaveBar on non-quota failure and pause states.
 * Guarantees zero banned words, human explanations, and safe technical sharing.
 */
export declare function FailureCard({ errorCode, httpStatus, supportName, onRetry, onCheckKey, onStartOver, onCopyMessage, copied, technicalContext, }: FailureCardProps): import("react").JSX.Element;

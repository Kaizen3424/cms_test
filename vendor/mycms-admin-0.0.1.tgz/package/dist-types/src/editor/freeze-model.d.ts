/**
 * Conflict freeze model (P2.9 — ADR-0004 P2.9 appendix).
 * Pure, no DOM, no React, no transport.
 *
 * Laws enforced here:
 *  - Frozen paths are MINIMAL COMMON NODES (a row may be a whole list or
 *    parent object, not a leaf).
 *  - Contested subtrees are rendered as plain text (ADR-0006 trust policy).
 *  - Decisions edit the form only; Save stays blocked until all rows are decided.
 *  - Path mutations use the value-domain writers (writeAtFieldPath/deleteAtFieldPath).
 *  - Late keystrokes typed while saving replay onto the reconciled tree
 *    (keystrokes-onto-chosen, never chosen-over-keystrokes).
 */
import type { FieldDescriptor, FieldPath } from "@mycms/core";
export interface FreezeRow {
    readonly path: FieldPath;
    readonly key: string;
    readonly label: string;
    readonly theirsRaw: string;
    readonly mineRaw: string;
    readonly theirsValue: unknown;
    readonly mineValue: unknown;
    readonly choice?: "theirs" | "mine";
}
export interface CreateFreezeRowsInput {
    readonly frozenFieldPaths: readonly FieldPath[];
    readonly remoteRaw: string;
    readonly mineTree: Readonly<Record<string, unknown>>;
    readonly fields?: readonly FieldDescriptor[];
    readonly initialChoices?: ReadonlyMap<string, "theirs" | "mine">;
}
/**
 * Reads a subtree at `path` from `tree`. Returns `undefined` if the path
 * does not exist.
 */
export declare function readAtFieldPath(tree: unknown, path: FieldPath): unknown;
/**
 * Serializes a subtree as plain text for safe rendering (plain text node law).
 */
export declare function formatSubtreeForDisplay(value: unknown): string;
/**
 * Derives a human-friendly label for a field path. Modeled root fields use
 * their configured label; nested paths and lists reflect their path structure.
 */
export declare function formatFieldPathLabel(path: FieldPath, fields?: readonly FieldDescriptor[]): string;
/**
 * Projects `frozenFieldPaths` into freeze rows comparing remote and local values.
 */
export declare function createFreezeRows(input: CreateFreezeRowsInput): readonly FreezeRow[];
/**
 * Applies a single choice ("theirs" or "mine") onto a tree via the core
 * path writers.
 */
export declare function applyFreezeChoice(tree: Readonly<Record<string, unknown>>, row: FreezeRow, choice: "theirs" | "mine"): Readonly<Record<string, unknown>>;
/**
 * Applies all decided rows onto the base tree.
 */
export declare function applyAllFreezeChoices(initialTree: Readonly<Record<string, unknown>>, rows: readonly FreezeRow[]): Readonly<Record<string, unknown>>;
/**
 * True iff every frozen row has a decision ("theirs" or "mine").
 */
export declare function allFreezeRowsDecided(rows: readonly FreezeRow[]): boolean;
/**
 * Replays late edits typed into `liveFormTree` since `baseMineTree` onto
 * `reconciledTree`.
 *
 * ADR-0004 P2.9 law: "replay direction is always keystrokes-onto-chosen,
 * never chosen-over-keystrokes, so no keystroke is lost."
 */
export declare function replayLateKeystrokes(input: {
    readonly baseMineTree: Readonly<Record<string, unknown>>;
    readonly liveFormTree: Readonly<Record<string, unknown>>;
    readonly reconciledTree: Readonly<Record<string, unknown>>;
}): Readonly<Record<string, unknown>>;

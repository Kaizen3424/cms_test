/**
 * Sticky save bar model (P2.6) — a PURE projection of two facts:
 *
 *  1. the save machine's phase (lifecycle truth), and
 *  2. the VALUE-domain dirty set (`computeDirtyPaths(formValue, baseValue)`).
 *
 * ADR-0004 P2.6 pin: "dirtiness is a VALUE-domain fact; lifecycle is the
 * machine. The save bar consumes both." A founder who undoes back to the base
 * sees `clean` while the machine may still be `dirty` — the machine never
 * un-dirties, and no event is invented for it.
 *
 * Precedence is deliberate: anything that BLOCKS a save outranks anything that
 * merely describes the edit state, an in-flight write outranks a stale local
 * diff (the write will land; the diff is re-evaluated after it settles), and a
 * fresh edit outranks the receipt of the save that preceded it.
 */
import type { SaveMachineState } from "@mycms/core";
import type { SaveBarStatus } from "./copy";
export type SaveBarTone = "neutral" | "positive" | "warning" | "danger";
export interface SaveBarInput {
    /** Coordinator state for this entry; `undefined` before the first dispatch. */
    readonly state: SaveMachineState | undefined;
    /** `computeDirtyPaths(formValue, baseValue).length > 0`. */
    readonly dirty: boolean;
    /** The last verdict published in this mount (drives the "Saved." receipt). */
    readonly justSaved: boolean;
    /** The last verdict was a no-op (nothing to write). */
    readonly justNoop: boolean;
    /** Cross-tab lease was displaced (`lease.onLost`). */
    readonly leaseLost: boolean;
    /** Freeze UI has undecided conflict rows (Save stays blocked until decided). */
    readonly freezePending?: boolean;
}
export interface SaveBarModel {
    readonly status: SaveBarStatus;
    readonly tone: SaveBarTone;
    /** The Save button is enabled only for a real, unblocked diff. */
    readonly canSave: boolean;
    /** "Try saving again" is offered after a failure or a manual pause. */
    readonly canRetry: boolean;
    /** "Start over from the latest version" is offered on a freeze. */
    readonly canStartOver: boolean;
    /** "Check again" re-acquires a lost lease (ADR-0004 P2.7 clearing law). */
    readonly canRecheck: boolean;
    /** True while a transport attempt is live or queued (submit stays disabled). */
    readonly busy: boolean;
}
/**
 * Projects the bar. Statuses that imply a blocked save win; `dirty` beats
 * `published` because edits typed WHILE a save was committing still need one.
 */
export declare function saveBarStatus(input: SaveBarInput): SaveBarStatus;
export declare function describeSaveBar(input: SaveBarInput): SaveBarModel;

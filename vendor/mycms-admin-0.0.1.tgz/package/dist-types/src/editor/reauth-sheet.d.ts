export interface ReauthSheetProps {
    readonly open: boolean;
    readonly supportName: string;
    /** True when prompted because an entry read 401'd; false for mid-save. */
    readonly isRead?: boolean;
    readonly onReauthenticated: () => void;
    readonly onCancel: () => void;
    readonly onSignOut: () => void;
    /** Injected reauthenticate callback (defaults to useRuntime().reauthenticate). */
    readonly reauthenticate?: (token: string, remember: boolean) => Promise<unknown>;
}
/**
 * In-place re-auth modal sheet (P2.10 — INV-A01).
 *
 * Appears when a mid-batch write or initial read fails with 401 AUTH_EXPIRED.
 * Preserves drafts in IndexedDB, probes the new key before accepting, updates
 * the transport token in-place without coordinator destruction, and resumes the save.
 */
export declare function ReauthSheet({ open, supportName, isRead, onReauthenticated, onCancel, onSignOut, reauthenticate: customReauthenticate, }: ReauthSheetProps): import("react").JSX.Element | null;

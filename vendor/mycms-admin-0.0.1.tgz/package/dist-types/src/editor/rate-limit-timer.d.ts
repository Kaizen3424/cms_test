export interface RateLimitTimerProps {
    /** Total milliseconds until rate limit window resets. */
    readonly waitMs: number;
    /** Callback when the founder clicks "Try saving now" manual override. */
    readonly onManualResume: () => void;
    /** Injected clock for deterministic testing. */
    readonly now?: () => number;
}
/**
 * Accessible rate-limit countdown UI (P2.10 — INV-N01).
 *
 * Rules:
 *  - Calculates remaining time against absolute target epoch (no drift in background tabs).
 *  - Visual ticker marked `aria-hidden="true"` so screen readers are NOT spammed every second.
 *  - Screen reader announcements fire only on milestones: start, 10-second warning, and resumption.
 *  - Provides "Try saving now" manual override calling coordinator.resume().
 */
export declare function RateLimitTimer({ waitMs, onManualResume, now }: RateLimitTimerProps): import("react").JSX.Element;

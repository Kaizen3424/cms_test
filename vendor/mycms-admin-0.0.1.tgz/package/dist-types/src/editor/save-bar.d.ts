import type { SaveBarModel } from "./save-bar-model";
export interface SaveBarProps {
    readonly model: SaveBarModel;
    readonly supportName: string;
    /** Local validation refused the save — overrides the title honestly. */
    readonly validationBlocked: boolean;
    readonly onSave: () => void;
    readonly onRetry: () => void;
    readonly onStartOver: () => void;
    readonly onRecheck: () => void;
    readonly onSignOut: () => void;
}
export declare function SaveBar({ model, supportName, validationBlocked, onSave, onRetry, onStartOver, onRecheck, onSignOut, }: SaveBarProps): import("react").JSX.Element;

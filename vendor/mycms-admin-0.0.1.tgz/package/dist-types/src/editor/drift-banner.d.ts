import type { DriftInfo } from "./drift-monitor";
export interface DriftBannerProps {
    readonly drift?: DriftInfo;
    readonly supportName: string;
    readonly onOpenDrawer: () => void;
}
export declare function DriftBanner({ drift, supportName, onOpenDrawer }: DriftBannerProps): import("react").JSX.Element;

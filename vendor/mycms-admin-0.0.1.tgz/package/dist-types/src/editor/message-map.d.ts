import type { FieldDescriptor, ParseIssue } from "@mycms/core";
/**
 * Static copy deck for parse and validation messages.
 * Every string is verified clean of the 9 banned words.
 */
export declare const MESSAGE_MAP_COPY: {
    readonly priceInteger: "Whole numbers only, e.g. 1450";
    readonly emailFormat: "Email needs @ and a dot";
    readonly chooseOption: "Choose one of the options";
    readonly relationUnknown: "Reference to a removed product";
    readonly relationCheckFailed: "Could not verify connection right now. Ask {name} for help.";
    readonly invalidDate: "Please enter a valid calendar date";
    readonly invalidPath: "Image path should start with /images/";
    readonly listTooShort: "Keep at least {min} item{plural}";
    readonly listTooLong: "At most {max} item{plural} allowed";
    readonly missingRequired: "Please fill in {label}";
    readonly outOfRange: "This value is outside the allowed range";
    readonly virtualKeyIgnored: "This web address is calculated automatically";
    readonly unmodeledKey: "This extra setting is preserved behind the scenes";
    readonly unknownFieldType: "This field type is not recognized. Ask {name} for help.";
    readonly fallbackError: "Please check this value";
};
/**
 * Translates a machine validation/parse issue into founder-friendly prose.
 */
export declare function humanizeIssue(issue: ParseIssue, field?: FieldDescriptor, supportName?: string): string;

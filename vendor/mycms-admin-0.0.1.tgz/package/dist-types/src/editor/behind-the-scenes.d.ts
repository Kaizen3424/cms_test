import type { FieldDescriptor } from "@mycms/core";
export interface BehindTheScenesProps {
    readonly fields: readonly FieldDescriptor[];
    readonly value: Record<string, unknown>;
    readonly supportName?: string;
}
export declare function BehindTheScenesDrawer({ fields, value, supportName, }: BehindTheScenesProps): import("react").JSX.Element | null;

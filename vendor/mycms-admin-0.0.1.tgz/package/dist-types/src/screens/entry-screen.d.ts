import type { FieldDescriptor } from "@mycms/core";
import type { EntryIndex, IndexedEntry } from "../runtime/entry-index";
export declare function EntryScreen(): import("react").JSX.Element;
export declare function FieldValue({ field, raw, entry, index, depth, }: {
    readonly field: FieldDescriptor;
    readonly raw: unknown;
    readonly entry: IndexedEntry;
    readonly index: EntryIndex | undefined;
    readonly depth: number;
}): import("react").JSX.Element;

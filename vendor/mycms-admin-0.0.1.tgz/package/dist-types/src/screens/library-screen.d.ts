export declare function LibraryScreen(): import("react").JSX.Element;

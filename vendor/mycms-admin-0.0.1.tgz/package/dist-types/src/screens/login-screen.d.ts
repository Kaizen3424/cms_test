/**
 * P1 login card — access key -> capability probe -> signed-in shell.
 * Copy law: founder vocabulary ("access key"), no token jargon in the primary
 * path; the remember copy is the exact ADR-0002 consent language.
 */
export declare function LoginScreen(): import("react").JSX.Element;

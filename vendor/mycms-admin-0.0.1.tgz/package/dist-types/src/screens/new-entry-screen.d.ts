export declare function NewEntryScreen(): import("react").JSX.Element;

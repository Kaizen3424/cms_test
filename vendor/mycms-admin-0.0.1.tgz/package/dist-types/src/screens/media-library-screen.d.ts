/**
 * Media library screen and picker modal — ADR-0007 §4, §5 (INV-N03, INV-M01, INV-M03).
 *
 * Browses all repository media assets, calculates budget health, inspects referential
 * usage via findReferences, and allows in-place asset replacement with 1h CDN honesty.
 */
export interface MediaItem {
    readonly repoPath: string;
    readonly publicPath: string;
    readonly filename: string;
    readonly size: number;
    readonly sha: string;
    readonly collectionName?: string;
}
export declare function MediaThumbnail({ sha, alt, className, }: {
    readonly sha: string;
    readonly alt: string;
    readonly className?: string;
}): import("react").JSX.Element;
export declare function MediaLibraryScreen(): import("react").JSX.Element;
export interface MediaPickerModalProps {
    readonly open: boolean;
    readonly onClose: () => void;
    readonly onSelect: (publicPath: string, altText?: string) => void;
    readonly filterCollection?: string;
}
export declare function MediaPickerModal({ open, onClose, onSelect, filterCollection, }: MediaPickerModalProps): import("react").JSX.Element | null;

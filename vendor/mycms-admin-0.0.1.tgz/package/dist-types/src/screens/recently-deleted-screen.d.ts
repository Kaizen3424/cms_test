/**
 * Recently deleted media screen — ADR-0007 §5 (INV-M03).
 *
 * Browses soft-deleted tombstones in _trash/, detects restoration collisions,
 * and restores media assets with honest founder-facing copy.
 */
export interface TrashedItem {
    readonly trashPath: string;
    readonly originalPath: string;
    readonly filename: string;
    readonly size: number;
    readonly sha: string;
}
export declare function RecentlyDeletedScreen(): import("react").JSX.Element;

import type { ReactNode } from "react";
export declare function AppShell({ children }: {
    readonly children?: ReactNode;
}): import("react").JSX.Element;

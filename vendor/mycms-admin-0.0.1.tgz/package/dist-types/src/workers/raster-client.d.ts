/**
 * Raster pipeline client dispatcher — ADR-0007 §2.
 *
 * Spawns and communicates with `raster.worker.ts` in browser environments.
 * Provides fallback in-process sniffing for headless/test environments where
 * Web Workers or OffscreenCanvas are unavailable.
 */
import type { RasterFailurePayload, RasterSuccessPayload } from "./raster-types";
export declare class RasterProcessingError extends Error {
    readonly code: RasterFailurePayload["error"]["code"];
    constructor(code: RasterFailurePayload["error"]["code"], message: string);
}
export interface ImageInput {
    readonly bytes: Uint8Array;
    readonly filename: string;
    readonly mimeType?: string;
}
/**
 * Normalizes an uploaded image file via the raster pipeline worker.
 */
export declare function normalizeImage(input: File | ImageInput): Promise<RasterSuccessPayload>;

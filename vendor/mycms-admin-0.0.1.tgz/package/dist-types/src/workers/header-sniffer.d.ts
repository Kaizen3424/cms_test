/**
 * Binary header dimension sniffer and decompression bomb guard — ADR-0007 §2 (INV-T04, INV-T05).
 *
 * Inspects raw bytes to extract image dimensions from JPEG, PNG, and WebP files
 * BEFORE bitmap decoding, preventing decompression bombs from exhausting browser memory.
 *
 * Pure TypeScript, zero DOM/Canvas dependencies — runs safely in both Web Workers and Node.
 */
import type { RasterErrorCode } from "./raster-types";
export declare const MAX_FILE_SIZE: number;
export declare const MAX_PIXELS = 24000000;
export declare const MAX_DIMENSION = 8192;
export interface ImageDimensions {
    readonly width: number;
    readonly height: number;
    readonly format: "jpeg" | "png" | "webp";
}
export type SniffResult = {
    readonly ok: true;
    readonly dimensions: ImageDimensions;
} | {
    readonly ok: false;
    readonly code: RasterErrorCode;
    readonly message: string;
};
/**
 * Sniffs image format and natural dimensions from binary headers.
 */
export declare function sniffImageHeader(bytes: Uint8Array, filename?: string, mimeType?: string): SniffResult;
/**
 * Detects whether the payload represents an SVG file (by filename, MIME, or magic bytes).
 */
export declare function isSvg(bytes: Uint8Array, filename?: string, mimeType?: string): boolean;
/**
 * Sanitizes a raw uploaded filename visibly (ADR-0007 §2).
 *
 * Example:
 *   "écu bad & sample!.JPG" -> "ecu-bad-sample.webp"
 */
export declare function sanitizeFilename(filename: string, targetExt?: string): string;

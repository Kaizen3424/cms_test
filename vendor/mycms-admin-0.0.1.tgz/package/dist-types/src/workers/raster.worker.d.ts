/**
 * Web Worker for client-side raster normalization — ADR-0007 §2 (INV-T04, INV-T05).
 *
 * Runs off the main UI thread:
 *  1. Header dimension sniffing & decompression bomb guard.
 *  2. Orientation-preserving decoding via `createImageBitmap({ imageOrientation: 'from-image' })`.
 *  3. Canvas re-encode stripping EXIF by construction.
 *  4. Target size ~400KB WebP (or JPEG fallback).
 */
export {};

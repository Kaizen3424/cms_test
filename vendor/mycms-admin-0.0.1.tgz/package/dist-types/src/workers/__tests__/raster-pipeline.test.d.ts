/**
 * Tests for the raster pipeline, binary header sniffer, decompression bomb guard,
 * SVG rejection, and filename sanitizer — ADR-0007 §2 (INV-T04, INV-T05).
 */
export {};

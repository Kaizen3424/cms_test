/**
 * Raster pipeline worker protocol and error codes — ADR-0007 §2 (INV-T04, INV-T05).
 */
export type RasterErrorCode = "FILE_TOO_LARGE" | "SVG_REJECTED" | "DIMENSIONS_TOO_LARGE" | "UNSUPPORTED_FORMAT" | "ENCODE_FAILED";
export interface RasterWorkerRequest {
    readonly id: string;
    readonly bytes: Uint8Array;
    readonly filename: string;
    readonly mimeType?: string;
    readonly targetBytes?: number;
}
export interface RasterSuccessPayload {
    readonly id: string;
    readonly ok: true;
    readonly bytes: Uint8Array;
    readonly mimeType: "image/webp" | "image/jpeg";
    readonly sanitizedFilename: string;
    readonly width: number;
    readonly height: number;
    readonly originalBytes: number;
    readonly finalBytes: number;
}
export interface RasterFailurePayload {
    readonly id: string;
    readonly ok: false;
    readonly error: {
        readonly code: RasterErrorCode;
        readonly message: string;
    };
}
export type RasterWorkerResponse = RasterSuccessPayload | RasterFailurePayload;

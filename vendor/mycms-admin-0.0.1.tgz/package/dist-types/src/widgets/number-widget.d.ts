import type { NumberFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/**
 * Numeric field. Empty input means "not set" (the key is removed), never `0`:
 * inventing a zero would publish a price nobody typed (default-immunity law).
 */
export declare function NumberWidget({ value, onChange, error, fieldConfig, }: WidgetProps<NumberFieldDescriptor>): import("react").JSX.Element;

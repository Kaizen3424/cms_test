import type { ParseIssue } from "@mycms/core";
/**
 * Filters all validation issues that apply to a given field name or path prefix.
 * e.g., prefix "images" matches "images", "images[0]", and "images[0].alt".
 */
export declare function findNestedIssues(issues: readonly ParseIssue[] | undefined, prefix: string): readonly ParseIssue[];
/**
 * Strips the field prefix from issues so that child widgets receive paths
 * relative to their own container.
 * e.g., "options[0].name" with prefix "options" becomes "[0].name".
 * "[0].name" with prefix "[0]" becomes "name".
 */
export declare function stripIssuePrefix(issues: readonly ParseIssue[] | undefined, prefix: string): readonly ParseIssue[];

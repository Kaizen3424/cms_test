/**
 * Reference Swatch Widget Exemplar (ADR-0009 §3)
 *
 * This exemplar demonstrates how custom widgets extend MyCMS without modifying
 * core types or bypassing the architectural boundary laws.
 *
 * ## The Four Seams of the Custom Widget Contract:
 *
 * 1. CONFIG:
 *    Host schemas define custom fields using either a standard factory (e.g.,
 *    `fields.select({ label: "Swatch", ... })` or a custom descriptor) joined
 *    to the widget BY NAME via `WidgetTypeName = FieldDescriptor["type"] | (string & {})`.
 *    In yve, product option values use:
 *    `swatch: z.enum(["accent", "muted", "secondary"]).default("accent")`
 *
 * 2. VALIDATE:
 *    Validation is strictly pure and isolated in `@mycms/core` (ADR-0003).
 *    The core validator ensures values match enum bounds, types, or custom rules.
 *    Widgets NEVER execute network I/O during validation.
 *
 * 3. SERIALIZE:
 *    Data remains canonical JSON on disk (ADR-0003, INV-S01). The swatch widget
 *    serializes clean scalar strings (`"accent" | "muted" | "secondary"`).
 *    Ephemeral UI state (such as focus or hover) is never persisted.
 *
 * 4. RENDER:
 *    The widget component is a pure React function of `WidgetProps<F>`.
 *    - It consumes `{ value, onChange, error, fieldConfig }`.
 *    - It strictly avoids receiving `backend`, PAT tokens, or raw fetch instances
 *      (standing panel veto, ADR-0009 §1).
 *    - It uses accessible semantic markup (`role="radiogroup"`, `aria-checked`,
 *      clear labels, keyboard navigation) and sanitizes any injected styles.
 */
import type { SelectFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "../contract";
export interface SwatchOption {
    readonly label: string;
    readonly value: string;
    readonly color: string;
}
export declare const DEFAULT_SWATCH_OPTIONS: readonly SwatchOption[];
export declare function ReferenceSwatchWidget({ value, onChange, error, fieldConfig, }: WidgetProps<SelectFieldDescriptor>): import("react").JSX.Element;

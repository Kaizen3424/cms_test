import type React from "react";
import type { WidgetRegistry } from "./contract";
export declare function WidgetRegistryProvider({ registry, children, }: {
    readonly registry: WidgetRegistry;
    readonly children: React.ReactNode;
}): React.JSX.Element;
export declare function useWidgetRegistry(): WidgetRegistry;

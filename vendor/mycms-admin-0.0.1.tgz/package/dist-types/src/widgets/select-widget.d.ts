import type { SelectFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/**
 * Choice field. Single → native `<select>` (empty option = not set);
 * multiple → a checkbox group writing a string array in option order.
 * Labels come from the descriptor, never from the raw stored value.
 */
export declare function SelectWidget({ value, onChange, error, fieldConfig, }: WidgetProps<SelectFieldDescriptor>): import("react").JSX.Element;

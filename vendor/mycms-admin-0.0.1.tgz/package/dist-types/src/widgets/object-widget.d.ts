import type { ObjectFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
export declare function ObjectWidget({ value, onChange, error, fieldConfig, services, nestedIssues, }: WidgetProps<ObjectFieldDescriptor>): import("react").JSX.Element;

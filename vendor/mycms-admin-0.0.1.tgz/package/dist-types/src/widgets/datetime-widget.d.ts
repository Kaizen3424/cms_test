import type { DatetimeFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/**
 * Date / date-time field. `dateOnly` stores `YYYY-MM-DD`; otherwise the field
 * round-trips through the browser-local input value and writes a UTC ISO
 * string on edit (the stored shape the site expects).
 */
export declare function DatetimeWidget({ value, onChange, error, fieldConfig, }: WidgetProps<DatetimeFieldDescriptor>): import("react").JSX.Element;
/** `2024-05-01T10:00:00.000Z` → `2024-05-01` (accepts a plain date unchanged). */
export declare function toDateInput(stored: string): string;
/** Stored ISO → the `YYYY-MM-DDTHH:mm` a datetime-local input expects (local). */
export declare function toLocalInput(stored: string): string;
/** Local input value → UTC ISO string (what the entry stores). */
export declare function fromLocalInput(local: string): string;

import { BooleanWidget } from "./boolean-widget";
import { DatetimeWidget } from "./datetime-widget";
import { ImageWidget } from "./image-widget";
import { ListWidget } from "./list-widget";
import { NumberWidget } from "./number-widget";
import { ObjectWidget } from "./object-widget";
import { ReferenceSwatchWidget } from "./reference-swatch/reference-swatch";
import { RelationWidget } from "./relation-widget";
import { SelectWidget } from "./select-widget";
import { StringWidget } from "./string-widget";
import { TextWidget } from "./text-widget";
export { useWidgetRegistry, WidgetRegistryProvider } from "./context";
export type { WidgetBinding, WidgetProps, WidgetRegistry, WidgetServices, WidgetTypeName, } from "./contract";
export { createWidgetRegistry, defineWidget } from "./contract";
export { findNestedIssues, stripIssuePrefix } from "./nested-issues";
export { BooleanWidget, DatetimeWidget, ImageWidget, ListWidget, NumberWidget, ObjectWidget, ReferenceSwatchWidget, RelationWidget, SelectWidget, StringWidget, TextWidget, };
export declare const WIDGETS: readonly [import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding, import("./contract").WidgetBinding];
/** The default registry the editor renders from. */
export declare const defaultWidgetRegistry: import("./contract").WidgetRegistry;
/** Field types that can be edited in the editor. */
export declare const EDITABLE_FIELD_TYPES: ReadonlySet<string>;

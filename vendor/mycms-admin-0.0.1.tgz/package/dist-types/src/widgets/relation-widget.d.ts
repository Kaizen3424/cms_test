import type { RelationFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
export declare function RelationWidget({ value, onChange, error, fieldConfig, services, }: WidgetProps<RelationFieldDescriptor>): import("react").JSX.Element;

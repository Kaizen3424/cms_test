/** Shared widget chrome — one input look, one label/hint/error pattern. */
import type { BaseFieldDescriptor } from "@mycms/core";
import type { ReactNode } from "react";
export declare const INPUT_CLASS = "w-full rounded-lg border border-border-soft bg-surface-raised px-3 py-2 text-sm text-text-primary outline-none transition-colors placeholder:text-text-muted/60 focus-visible:border-accent/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-60";
export declare function inputClass(error: string | undefined): string;
/** `aria-describedby` target list — hint and error, each present only when real. */
export declare function describedBy(id: string, field: BaseFieldDescriptor, error: string | undefined): string | undefined;
export declare function WidgetFrame({ id, field, error, children, }: {
    readonly id: string;
    readonly field: BaseFieldDescriptor;
    readonly error: string | undefined;
    readonly children: ReactNode;
}): import("react").JSX.Element;
export declare function FieldMessages({ id, field, error, }: {
    readonly id: string;
    readonly field: BaseFieldDescriptor;
    readonly error: string | undefined;
}): import("react").JSX.Element;

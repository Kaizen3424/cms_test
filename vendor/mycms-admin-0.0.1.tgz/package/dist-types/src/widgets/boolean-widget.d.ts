import type { BooleanFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/** On/off field. A false value is real data (it is written as `false`). */
export declare function BooleanWidget({ value, onChange, error, fieldConfig, }: WidgetProps<BooleanFieldDescriptor>): import("react").JSX.Element;

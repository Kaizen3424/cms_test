import type { ListFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
export declare function ListWidget({ value, onChange, error, fieldConfig, services, nestedIssues, }: WidgetProps<ListFieldDescriptor>): import("react").JSX.Element;

import type { TextFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/** Long-form text — the multi-line textarea (yve captions, descriptions). */
export declare function TextWidget({ value, onChange, error, fieldConfig, }: WidgetProps<TextFieldDescriptor>): import("react").JSX.Element;

import type { StringFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
/** Single-line text (email/url input types when the descriptor asks). */
export declare function StringWidget({ value, onChange, error, fieldConfig, }: WidgetProps<StringFieldDescriptor>): import("react").JSX.Element;

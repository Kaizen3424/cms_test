import type { ImageFieldDescriptor } from "@mycms/core";
import type { WidgetProps } from "./contract";
export declare function ImageWidget({ value, onChange, error, fieldConfig, services, }: WidgetProps<ImageFieldDescriptor>): import("react").JSX.Element;

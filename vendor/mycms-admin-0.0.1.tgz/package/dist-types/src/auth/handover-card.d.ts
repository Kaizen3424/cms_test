import { type TokenExpiryConfig } from "./token-expiry";
export interface HandoverCardProps {
    readonly onSaved?: (config: TokenExpiryConfig) => void;
}
export declare function HandoverCard({ onSaved }: HandoverCardProps): import("react").JSX.Element;

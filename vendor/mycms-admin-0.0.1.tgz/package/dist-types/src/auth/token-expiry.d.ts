import type { TokenExpiryConfig } from "@mycms/core/web";
export { clearTokenExpiryConfig, getTokenExpiryConfig, setTokenExpiryConfig, } from "@mycms/core/web";
export type { TokenExpiryConfig };
export interface TokenExpiryState {
    readonly expiresAt: string;
    readonly daysRemaining: number;
    readonly isExpiringSoon: boolean;
    readonly isCritical: boolean;
    readonly isExpired: boolean;
}
export declare function describeTokenExpiry(config: TokenExpiryConfig, nowEpochMs?: number): TokenExpiryState;

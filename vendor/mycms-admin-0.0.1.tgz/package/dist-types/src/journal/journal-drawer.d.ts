export interface JournalDrawerProps {
    readonly open: boolean;
    readonly onOpenChange: (open: boolean) => void;
}
export declare function JournalDrawer({ open, onOpenChange }: JournalDrawerProps): import("react").JSX.Element;

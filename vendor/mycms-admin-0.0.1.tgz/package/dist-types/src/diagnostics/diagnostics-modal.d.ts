import type { LogRecord } from "@mycms/core";
export interface DiagnosticsModalProps {
    readonly open: boolean;
    readonly onOpenChange: (open: boolean) => void;
}
export declare function formatDiagnosticsReport(history: readonly LogRecord[], meta: {
    readonly site: string;
    readonly branch: string;
    readonly repo: string;
    readonly supportName: string;
    readonly timestamp: string;
}): string;
export declare function DiagnosticsModal({ open, onOpenChange }: DiagnosticsModalProps): import("react").JSX.Element;

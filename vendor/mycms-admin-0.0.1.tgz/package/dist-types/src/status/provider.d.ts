/**
 * React composition for deploy-status (ADR-0008 P2.8 appendix).
 *
 * `StatusProvider` owns ONE sha-keyed refcounted registry for the signed-in
 * backend generation. Per-entry chips key reads to the session publish
 * journal; the top-bar banner watches whole-site truth for the current head.
 *
 * Status checking is off when the backend capability or the login probe says
 * so: no watcher is created and the UI renders the off copy (never a spinner
 * loop). Reads degrade to `unavailable`, never to `failed`.
 */
import type { CapabilityProbeResult, DeployStatusSnapshot, GitBackend, StatusTiming } from "@mycms/core";
import { type ReactNode } from "react";
import type { PublishStore } from "./publish-store";
export interface StatusProviderDeps {
    /** undefined until the login probe answers. */
    readonly probe: CapabilityProbeResult | undefined;
    readonly backend: GitBackend | undefined;
    readonly branch: string;
    /** `deploy.contexts`; empty means the statuses fallback stays off. */
    readonly contexts?: readonly string[];
    /** Session publish journal: `entryId -> latestCommitSha`. */
    readonly publishStore: PublishStore;
    /** Host/e2e cadence overrides (ADR-0008 P2.8). */
    readonly statusTiming?: Partial<StatusTiming>;
}
export interface UseStatusResult {
    /** undefined before a lease exists or while status checking is off. */
    readonly snapshot: DeployStatusSnapshot | undefined;
    /** Support is off (capability or probe) — render the off copy. */
    readonly isDisabled: boolean;
}
export declare function StatusProvider({ deps, children, }: {
    readonly deps: StatusProviderDeps;
    readonly children: ReactNode;
}): import("react").JSX.Element;
/** Per-entry truth, keyed to the entry's latest published sha. */
export declare function useEntryStatus(sha: string): UseStatusResult;
/** Whole-site truth; follows the head forward when a newer save supersedes it. */
export declare function useSiteStatus(): UseStatusResult;
/** The entry's latest published sha from the session journal (P2.8). */
export declare function usePublishedSha(entryId: string): string | undefined;

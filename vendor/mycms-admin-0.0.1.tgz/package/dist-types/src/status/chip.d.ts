/**
 * Deploy-status surfaces (ADR-0008 P2.8 appendix): a per-entry chip keyed to
 * the entry's latest published sha, and the top-bar banner carrying whole-site
 * truth for the current head.
 *
 * Never a spinner: an off feature renders the off copy (banner only), and a
 * degraded read renders the honest unavailable copy with its cause hint where
 * there is room. Detail links open the failing run or commit page, never a raw
 * dashboard. All copy comes from `./copy` (the banned-word sweep scans it).
 */
export interface StatusChipProps {
    /** Entry's latest published sha (the per-commit key), if any. */
    readonly sha: string | undefined;
}
/**
 * Per-entry truth. Renders nothing before this session published the entry,
 * and nothing when status checking is off — the banner owns the single off
 * message, so a folder of entries is not a wall of identical lines.
 */
export declare function StatusChip({ sha }: StatusChipProps): import("react").JSX.Element | null;
/** Whole-site truth for the head every visitor is served. */
export declare function StatusBanner(): import("react").JSX.Element | null;

export declare function TopBarHeartbeat({ onOpenJournal }: {
    readonly onOpenJournal?: () => void;
}): import("react").JSX.Element | null;
export declare function LoginHeartbeat({ lastConnected }: {
    readonly lastConnected?: string;
}): import("react").JSX.Element;

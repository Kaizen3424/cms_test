/**
 * Session-only publish journal (ADR-0008 P2.8 appendix) —
 * `entryId → latestCommitSha`, filled from the `published` verdict.
 *
 * A reload starts empty; a persistent publish journal is P5.2 work and an
 * explicit non-goal of P2.8. Framework-free: plain Map + subscriber set.
 */
export interface PublishStore {
    publish(entryId: string, sha: string): void;
    shaFor(entryId: string): string | undefined;
    subscribe(listener: () => void): () => void;
    clear(): void;
}
export declare function createPublishStore(): PublishStore;

/**
 * Sha-keyed refcounted registry (ADR-0008 P2.8 appendix): one watcher per sha,
 * N entries published in one sweep share one poller, the last release stops it,
 * terminal states stop themselves, and a superseded sha annotates + stops
 * (INV-D03: a late run never repaints newer state).
 *
 * Timing is fully injected — the registry receives the same seams the core
 * watcher does, so these tests own the clock and the scheduler.
 */
export {};

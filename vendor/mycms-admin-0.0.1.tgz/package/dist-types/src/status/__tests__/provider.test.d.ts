/**
 * React wiring for deploy-status (ADR-0008 P2.8 appendix): the publish journal
 * turns into a per-entry chip only after the `published` verdict lands, the
 * banner carries whole-site truth for the current head, a missing probe
 * permission renders the off copy with no reads at all, and a read error
 * degrades to `unavailable` — never `failed`.
 */
export {};

/**
 * Session publish journal (ADR-0008 P2.8 appendix): `entryId -> latestCommitSha`
 * filled from the `published` verdict. A reload starts empty — the persistent
 * journal is P5.2 work and an explicit non-goal here.
 */
export {};

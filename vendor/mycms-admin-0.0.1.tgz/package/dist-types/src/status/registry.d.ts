/**
 * Sha-keyed refcounted status registry (ADR-0008 P2.8 appendix).
 *
 * One watcher per sha; `acquire(sha) → lease` refcounts it so N consumers
 * published in one sweep share a single poller. Terminal watchers stop
 * themselves; the last release stops the watcher and drops the snapshot.
 *
 * Framework-free: no React, no globals. Timing/randomness enter through the
 * same injected seams the core watcher uses.
 */
import type { DeployStatusSnapshot, StatusReads, StatusTiming } from "@mycms/core";
export interface StatusRegistryOptions {
    readonly reads: StatusReads;
    readonly contexts?: readonly string[];
    readonly timing?: Partial<StatusTiming>;
    readonly now: () => number;
    readonly schedulePoll: (delayMs: number, task: () => void) => () => void;
    readonly random: () => number;
}
export interface StatusLease {
    getSnapshot(): DeployStatusSnapshot;
    subscribe(listener: () => void): () => void;
    release(): void;
}
export interface StatusRegistry {
    acquire(sha: string): StatusLease;
    dispose(): void;
}
export declare function createStatusRegistry(options: StatusRegistryOptions): StatusRegistry;

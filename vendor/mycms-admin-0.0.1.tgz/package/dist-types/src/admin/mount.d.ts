import type { AdminMountOptions } from "./types";
export declare function mountAdmin(el: HTMLElement, options: AdminMountOptions): void;
export { BlobCacheManager, BlobCacheProvider, useBlobCache, useBlobPreview, } from "../runtime/blob-cache";

/**
 * Type-safe string interpolation helper (P5.6).
 * Safely replaces {placeholder} tokens in templates using split/join.
 * Never uses regex, ensuring values with `$` characters (e.g. prices) are treated as literal text.
 */
export declare function t(template: string, values?: Readonly<Record<string, string | number>>): string;

/**
 * Read-side entry index — the P1 ServicesProvider stand-in (ADR-0009).
 *
 * One tree snapshot becomes a collection-grouped index. Each content document is
 * parsed leniently, relation values are checked against the whole index, and
 * unmodeled keys stay in `untouched` for display/preservation. No writes, no
 * defaults injected, no second serializer.
 */
import type { AdminConfig, FieldDescriptor, FilesCollectionDescriptor, FolderCollectionDescriptor, GitBackend, JsonValue, ParseIssue, TreeRead } from "@mycms/core";
export interface IndexedEntry {
    readonly collectionName: string;
    readonly collection: FolderCollectionDescriptor | FilesCollectionDescriptor;
    readonly path: string;
    readonly slug: string;
    readonly title: string;
    readonly fields: readonly FieldDescriptor[];
    readonly media: AdminConfig["media"];
    readonly raw: Readonly<Record<string, unknown>>;
    readonly value: Readonly<Record<string, unknown>>;
    readonly issues: readonly ParseIssue[];
    readonly untouched: Readonly<Record<string, JsonValue>>;
    /** Decoded source bytes — the editor's `baseRaw` for rebase + compose (P2.6). */
    readonly rawText: string;
    readonly blobSha: string;
}
export interface EntryIndex {
    readonly entries: readonly IndexedEntry[];
    readonly byCollection: ReadonlyMap<string, readonly IndexedEntry[]>;
    readonly byPath: ReadonlyMap<string, IndexedEntry>;
    readonly bySlug: ReadonlyMap<string, ReadonlyMap<string, IndexedEntry>>;
}
export interface LoadEntryIndexOptions {
    readonly config: AdminConfig;
    readonly tree: TreeRead;
    readonly backend: GitBackend;
    readonly branch: string;
}
export declare function loadEntryIndex(options: LoadEntryIndexOptions): Promise<EntryIndex>;
/** Counts used by the library drift chip and entry banner. */
export declare function issueCounts(entry: IndexedEntry): {
    errors: number;
    warnings: number;
};
/** Relation display lookup: valueField is the slug in the yve corpus. */
export declare function findRelationEntry(index: EntryIndex | undefined, collection: string, value: string): IndexedEntry | undefined;

/**
 * Image source guard for repository-provided paths. P1 renders only the
 * repository's own media folder (`/images/**`); remote image hosts are rejected
 * outright, so no forbidden raw-content host can ever become an `src` value.
 */
export declare function imageSource(value: unknown, publicFolder: string): string | undefined;
/** Safe absolute preview URL from a collection template + site origin. */
export declare function previewUrl(template: string | undefined, values: Readonly<Record<string, unknown>>, siteUrl: string | undefined): string | undefined;

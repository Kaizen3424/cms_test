/**
 * Ref-counted blob preview cache and lifecycle manager — ADR-0007 §3 (INV-N03).
 *
 * Previews MUST read from the git blob API (never raw.githubusercontent.com).
 * In-flight requests for the same SHA are deduplicated.
 * Object URLs are reference-counted and revoked when all subscribers unmount.
 */
import type { GitBackend } from "@mycms/core";
import type { ReactNode } from "react";
export interface BlobCacheEntry {
    readonly url: string;
    refCount: number;
    readonly bytes: Uint8Array;
    readonly mimeType: string;
}
export declare function sniffMimeType(bytes: Uint8Array): string;
export declare class BlobCacheManager {
    private entries;
    private inFlight;
    private backend;
    constructor(backend?: GitBackend);
    setBackend(backend: GitBackend | undefined): void;
    getEntry(sha: string): BlobCacheEntry | undefined;
    getRefCount(sha: string): number;
    acquire(sha: string): Promise<string>;
    release(sha: string): void;
    clear(): void;
}
export declare const BlobCacheContext: import("react").Context<BlobCacheManager | undefined>;
export interface BlobCacheProviderProps {
    readonly backend?: GitBackend;
    readonly manager?: BlobCacheManager;
    readonly children: ReactNode;
}
export declare function BlobCacheProvider({ backend, manager, children }: BlobCacheProviderProps): import("react").JSX.Element;
export declare function useBlobCache(): BlobCacheManager | undefined;
export interface BlobPreviewResult {
    readonly url: string | undefined;
    readonly loading: boolean;
    readonly error: string | undefined;
}
export declare function useBlobPreview(sha: string | undefined, customCache?: BlobCacheManager): BlobPreviewResult;

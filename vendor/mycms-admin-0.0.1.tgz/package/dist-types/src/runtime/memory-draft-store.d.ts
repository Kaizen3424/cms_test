/**
 * In-memory `DraftStore` fallback. Used when IndexedDB is unavailable (private
 * mode, exotic engines) and by admin tests. Crash protection degrades to the
 * lifetime of the tab — never a silent no-op, the editor still writes drafts.
 */
import type { DraftStore } from "@mycms/core";
export declare function createMemoryDraftStore(): DraftStore;

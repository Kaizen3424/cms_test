/**
 * Runtime composition for the P1 admin: PAT lifecycle, GitHub read transport,
 * immutable snapshot cache, and React Query as the ONLY UI cache (ADR-0001/0002/0004).
 */
import type { AdminConfig, CapabilityProbeResult, DraftStore, Logger, SaveCoordinator, SaveLease } from "@mycms/core";
import { GithubBackend, PatProvider, SnapshotStore } from "@mycms/core";
import type { DiscardStore, JournalStore, OnboardingStore } from "@mycms/core/web";
import type { ReactNode } from "react";
import type { AdminMountOptions, AdminRepository, SupportContext } from "../admin/types";
import type { PublishStore } from "../status/publish-store";
import type { EntryIndex } from "./entry-index";
type AuthStatus = "loading" | "signedOut" | "signedIn";
interface RuntimeValue {
    readonly config: AdminConfig;
    readonly support: SupportContext;
    readonly repository: AdminRepository;
    readonly auth: PatProvider;
    readonly status: AuthStatus;
    readonly probe: CapabilityProbeResult | undefined;
    readonly bootNotice: string | undefined;
    readonly backend: GithubBackend | undefined;
    readonly snapshots: SnapshotStore;
    readonly epoch: number;
    /** Crash-safety store for editor drafts (IDB, or memory fallback). */
    readonly drafts: DraftStore;
    /** Session-only publish journal: entryId → latestCommitSha (P2.8). */
    readonly publishStore: PublishStore;
    /** Persistent publish journal store (P5.2). */
    readonly journalStore: JournalStore;
    /** Onboarding status store (P5.3). */
    readonly onboardingStore: OnboardingStore;
    /** Discard archive store (P5.5). */
    readonly discardStore: DiscardStore;
    /** Memory-only diagnostics logger (P5.10). */
    readonly logger: Logger;
    /** Save orchestration for this backend generation (P2.6 editor). */
    readonly coordinator: SaveCoordinator | undefined;
    /** Cross-tab UX serialization; undefined when no carrier is available. */
    readonly lease: SaveLease | undefined;
    readonly signIn: (token: string, remember: boolean) => Promise<CapabilityProbeResult>;
    readonly reauthenticate: (token: string, remember: boolean) => Promise<CapabilityProbeResult>;
    readonly signOut: () => Promise<void>;
}
interface AdminRuntimeProviderProps {
    readonly options: AdminMountOptions;
    readonly children: ReactNode;
}
export declare function AdminRuntimeProvider({ options, children }: AdminRuntimeProviderProps): import("react").JSX.Element;
export declare function useRuntime(): RuntimeValue;
export declare function useRuntimeSafe(): RuntimeValue | undefined;
export declare function useJournalStore(): JournalStore;
export declare function useOnboardingStore(): OnboardingStore;
export declare function useDiscardStore(): DiscardStore;
export declare function useLogger(): Logger;
export interface PublishEntryMeta {
    readonly title?: string;
    readonly collectionName?: string;
    readonly author?: string;
    readonly publicUrl?: string;
}
/**
 * Captures the `published` verdict's `commitSha` into both the session publish
 * store (for live chips) and the persistent IDB journal (P5.2).
 */
export declare function usePublishEntry(): (entryId: string, commitSha: string, meta?: PublishEntryMeta) => void;
export declare function useSnapshot(): import("@tanstack/react-query").UseQueryResult<{
    head: string;
    tree: import("@mycms/core").TreeRead;
}, Error>;
export declare function useEntryIndex(): import("@tanstack/react-query").UseQueryResult<EntryIndex, Error>;
export {};

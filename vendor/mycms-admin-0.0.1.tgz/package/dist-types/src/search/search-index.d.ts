import type { AdminConfig } from "@mycms/core";
import type { IndexedEntry } from "../runtime/entry-index";
export interface TextPart {
    readonly text: string;
    readonly isMatch: boolean;
}
export interface SearchResult {
    readonly id: string;
    readonly collectionName: string;
    readonly collectionLabel: string;
    readonly slug: string;
    readonly title: string;
    readonly matchedField: string;
    readonly snippetParts?: readonly TextPart[];
    readonly rawSnippet?: string;
}
export interface SearchGroup {
    readonly collectionName: string;
    readonly collectionLabel: string;
    readonly results: readonly SearchResult[];
}
/**
 * Splits plain text into matching and non-matching segments for safe rendering.
 * Pure React elements only — zero dangerouslySetInnerHTML (01-spec §2.2).
 */
export declare function splitByMatch(text: string, query: string): readonly TextPart[];
/**
 * Searches all loaded entries in EntryIndex across collections.
 * Case-insensitive token-based matching over titles, prices/numbers,
 * materials, image alt descriptions, and text fields.
 */
export declare function searchIndex(query: string, entries: readonly IndexedEntry[], config: AdminConfig): readonly SearchGroup[];

import type React from "react";
export interface GlobalSearchModalProps {
    readonly open: boolean;
    readonly onOpenChange: (open: boolean) => void;
}
export declare function GlobalSearchModal({ open, onOpenChange }: GlobalSearchModalProps): React.JSX.Element;

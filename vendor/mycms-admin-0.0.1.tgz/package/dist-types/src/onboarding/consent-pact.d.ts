export interface ConsentPactCardProps {
    readonly onTakeTour: () => void;
    readonly onDismiss: () => void;
}
export declare function ConsentPactCard({ onTakeTour, onDismiss }: ConsentPactCardProps): import("react").JSX.Element;

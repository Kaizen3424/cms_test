export interface ProductTourDialogProps {
    readonly open: boolean;
    readonly onOpenChange: (open: boolean) => void;
    readonly onComplete?: () => void;
}
export declare function ProductTourDialog({ open, onOpenChange, onComplete }: ProductTourDialogProps): import("react").JSX.Element;

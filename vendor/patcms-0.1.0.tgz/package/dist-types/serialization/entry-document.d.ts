/**
 * The ONE save-path document composer (ADR-0004 "P2.6 editor integration pins";
 * INV-S01/S03).
 *
 * The editor holds a MODELED value (`parseEntry().value`, which includes the
 * virtual `slug`) plus the `untouched` map for unmodeled keys. Bytes must be
 * composed from BOTH: a modeled-only tree would make every unmodeled key look
 * deleted to `rebase()` (silent data loss), and a tree that still carries
 * `slug` would write the virtual key into the file.
 *
 * Composition law: merge untouched pointers verbatim → drop every declared
 * `slug` field (virtual, derived from the filename, never persisted) →
 * `serializeDocument()` so an unchanged document keeps its original bytes.
 */
import type { FieldDescriptor } from "../fields/types";
import type { JsonValue } from "../safety/untrusted-json";
import type { JsonDocument } from "./document";
export interface ComposeEntryDocumentInput {
    readonly fields: readonly FieldDescriptor[];
    /** Modeled value (`parseEntry`/`validateEntryForSave` output). */
    readonly value: Readonly<Record<string, unknown>>;
    /** Unmodeled keys, JSON-Pointer keyed (`parseEntry().untouched`). */
    readonly untouched: Readonly<Record<string, JsonValue>>;
    /** The document the form was loaded from (`parseJsonDocument(baseRaw)`). */
    readonly document: JsonDocument;
}
export interface ComposedEntryDocument {
    readonly raw: string;
    readonly value: JsonValue;
}
export declare function composeEntryDocument(input: ComposeEntryDocumentInput): ComposedEntryDocument;

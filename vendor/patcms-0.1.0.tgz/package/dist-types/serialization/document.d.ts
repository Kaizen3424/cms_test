/**
 * Source-preserving JSON documents (ADR-0003 P1 addendum / INV-S01).
 *
 * Untouched documents return their original bytes — the yve corpus is
 * Prettier-shaped, so re-printing would create phantom diffs. Only edited or
 * new documents use the canonical printer (2-space, author key order, LF,
 * trailing newline).
 */
import type { JsonValue, UntrustedJsonIssue } from "../safety/untrusted-json";
export type NewlineStyle = "lf" | "crlf" | "none";
export interface JsonDocument {
    readonly raw: string;
    readonly value: JsonValue;
    readonly newline: NewlineStyle;
    readonly strippedKeys: readonly string[];
}
export type ParseJsonDocumentResult = {
    readonly ok: true;
    readonly document: JsonDocument;
} | {
    readonly ok: false;
    readonly issues: readonly UntrustedJsonIssue[];
};
export declare function parseJsonDocument(raw: string): ParseJsonDocumentResult;
/**
 * Returns original bytes when the value is unchanged; otherwise canonical JSON.
 * Callers must pass a JSON-safe value (parse output is).
 */
export declare function serializeDocument(document: JsonDocument, nextValue?: JsonValue): string;
export declare function canonicalJson(value: JsonValue): string;
export declare function detectNewline(raw: string): NewlineStyle;
export declare function normalizeNewlines(text: string): string;
/** Deep equality with author key order ignored (no-op saves keep original order). */
export declare function jsonEqual(left: unknown, right: unknown): boolean;
/** CRLF/format-insensitive canonical comparison used by no-op/ETag tests. */
export declare function documentsCanonicallyEqual(left: string, right: string): boolean;

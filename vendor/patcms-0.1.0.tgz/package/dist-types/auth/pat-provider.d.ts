/**
 * PatProvider — ADR-0002 token lifecycle.
 *
 * A token lives in memory after a successful probe. Optional persistence is
 * explicit ("Remember on this device"); bootstrap = restore → re-probe and a
 * failed re-probe wipes the stored token before the login prompt. The token is
 * never placed in a URL, never logged, and never returned in UI state.
 */
import type { AuthProvider, TokenStore } from "./index";
import type { CapabilityProbeResult } from "./types";
export interface PatProviderOptions {
    readonly store: TokenStore;
    readonly probe: (token: string) => Promise<CapabilityProbeResult>;
}
export interface SignInOptions {
    readonly remember?: boolean;
}
export declare class PatProvider implements AuthProvider {
    #private;
    readonly kind: "pat";
    constructor(options: PatProviderOptions);
    get isSignedIn(): boolean;
    get lastProbe(): CapabilityProbeResult | undefined;
    getToken(): string | undefined;
    probe(): Promise<CapabilityProbeResult>;
    signIn(token: string, options?: SignInOptions): Promise<CapabilityProbeResult>;
    /** Bootstrap: restore then re-probe; any failure wipes the persisted token. */
    restore(): Promise<CapabilityProbeResult | undefined>;
    /** Re-probe after a 401/403/422; failed re-probe wipes (INV-A03/INV-A04). */
    reprobe(): Promise<CapabilityProbeResult>;
    signOut(): Promise<void>;
}

/**
 * Snapshot store — P1.5 / INV-P08 foundation.
 *
 * The verified head advances ONLY through `advance(expected, next)`: a stale
 * query result carrying an old expected head can never overwrite a newer one.
 * Trees and blobs are keyed by immutable SHAs; ETags live here (HTTP cache),
 * never in a second UI cache (React Query is the only UI cache).
 */
import type { FileRead, TreeRead } from "../backend/types";
export interface TreeCacheEntry {
    readonly tree: TreeRead;
    readonly etag?: string;
}
export interface FileCacheEntry {
    readonly file: FileRead;
    readonly etag?: string;
}
export declare class SnapshotStore {
    #private;
    get headSha(): string | undefined;
    /**
     * Advances the verified head only when the caller's expected current head
     * still matches. Returns true when the head changed.
     */
    advance(expectedCurrent: string | undefined, next: string): boolean;
    /** Test/restore hook — deliberately explicit, never called by stale reads. */
    forceHead(sha: string): void;
    putTree(commitSha: string, entry: TreeCacheEntry): void;
    getTree(commitSha: string): TreeCacheEntry | undefined;
    putFile(blobSha: string, entry: FileCacheEntry): void;
    getFile(blobSha: string): FileCacheEntry | undefined;
    clear(): void;
}

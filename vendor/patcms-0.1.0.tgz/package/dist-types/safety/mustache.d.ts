/**
 * Mustache-lite — `{{ fields.title }}` substitution for list summaries and
 * relation labels. Deliberately tiny: no partials, no logic, no HTML escaping
 * (values are rendered as TEXT NODES by callers; never as markup).
 */
export type TemplateValues = Readonly<Record<string, unknown>>;
export declare function mustacheLite(template: string, values: TemplateValues): string;
/** Resolves `a.b[0].c` without eval; only own properties are visible. */
export declare function readPath(root: unknown, path: string): unknown;

/**
 * Untrusted JSON parse — ADR-0006 §4 (the ONLY entry/config parse).
 *
 * Repo content is untrusted input. This module:
 *  - refuses oversize input before parsing (entry ≤2MB),
 *  - re-keys the tree prototype-free, stripping `__proto__|constructor|prototype`
 *    at EVERY depth (no object spread/merge of parsed data),
 *  - enforces depth ≤64 and list ≤5k items,
 *  - returns a Result — malformed content must render, never throw.
 */
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | readonly JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export declare const UNTRUSTED_JSON_LIMITS: {
    /** Entry cap from ADR-0006 §5. */
    readonly maxBytes: number;
    readonly maxDepth: 64;
    readonly maxListItems: 5000;
};
export type UntrustedJsonFailureCode = "INVALID_JSON" | "TOO_LARGE" | "TOO_DEEP" | "TOO_MANY_ITEMS";
export interface UntrustedJsonIssue {
    readonly code: UntrustedJsonFailureCode;
    /** Dot/bracket path of the offending value (`$` for the root). */
    readonly path?: string;
    readonly detail?: string;
}
export interface UntrustedJsonOptions {
    readonly maxBytes?: number;
    readonly maxDepth?: number;
    readonly maxListItems?: number;
}
export type UntrustedJsonResult = {
    readonly ok: true;
    readonly value: JsonValue;
    /** Paths whose dangerous keys were stripped (never rendered). */
    readonly strippedKeys: readonly string[];
} | {
    readonly ok: false;
    readonly issues: readonly UntrustedJsonIssue[];
};
/**
 * Parses untrusted JSON text. Never throws; failures are Result values.
 * Key insertion order is preserved (the serializer depends on author order).
 */
export declare function parseUntrustedJson(text: string, options?: UntrustedJsonOptions): UntrustedJsonResult;
/** UTF-8 byte length without DOM/Node globals (core stays runtime-agnostic). */
export declare function utf8ByteLength(text: string): number;

/**
 * Slug is VIRTUAL: derived from the entry filename, never stored in JSON.
 * `src/content/products/iris-no-7.json` → `iris-no-7`.
 */
export declare function deriveSlug(filePath: string): string | null;
/**
 * Proposes a filename-safe slug from arbitrary text (usually the identifier
 * field). ASCII-folded and lowercased so the result is always a valid repo
 * path segment; non-Latin text that folds to nothing becomes `"entry"`, which
 * the caller can override with an explicit slug.
 */
export declare function slugify(input: string): string;

/**
 * URL guard — preview/links may only be http(s) or same-origin relative paths.
 * `javascript:`, `data:`, `file:`, protocol-relative and control-char bypasses fail.
 */
export type SafeUrlFailureCode = "EMPTY" | "CONTROL_CHAR" | "BACKSLASH" | "PROTOCOL_RELATIVE" | "UNSAFE_SCHEME" | "INVALID";
export interface SafeUrlOptions {
    /** Allow same-origin relative paths starting with a single `/` (default true). */
    readonly allowRelative?: boolean;
}
export type SafeUrlResult = {
    readonly ok: true;
    readonly value: string;
} | {
    readonly ok: false;
    readonly code: SafeUrlFailureCode;
    readonly detail?: string;
};
export declare function safeUrl(input: string, options?: SafeUrlOptions): SafeUrlResult;
export declare function isSafeUrl(input: string, options?: SafeUrlOptions): boolean;

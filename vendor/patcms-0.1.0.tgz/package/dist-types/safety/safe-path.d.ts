/**
 * Path guard — repo-relative paths and public media paths.
 *
 * Rules:
 *  - no control chars, no backslashes (Windows separators are a bypass vector),
 *  - no `..` segments, raw or percent-encoded (`%2e%2e`), no encoded separators,
 *  - no schemes/drive letters, no protocol-relative paths,
 *  - public paths require a leading `/`; repo paths forbid it,
 *  - optional prefix must match at a segment boundary (`/images-other` ≠ `/images`).
 */
export type SafePathFailureCode = "EMPTY" | "CONTROL_CHAR" | "BACKSLASH" | "ABSOLUTE" | "SCHEME" | "EMPTY_SEGMENT" | "TRAVERSAL" | "ENCODED_SEPARATOR" | "ENCODED_TRAVERSAL" | "PREFIX_MISMATCH" | "INVALID_PREFIX";
export interface SafePathOptions {
    /** Required segment prefix, e.g. `/images` (public) or `src/content` (repo). */
    readonly prefix?: string;
    /** true = public URL path (leading slash required); false = repo path (no leading slash). */
    readonly absolute?: boolean;
}
export type SafePathResult = {
    readonly ok: true;
    readonly value: string;
} | {
    readonly ok: false;
    readonly code: SafePathFailureCode;
    readonly detail?: string;
};
export declare function safePath(input: string, options?: SafePathOptions): SafePathResult;
export declare function isSafePath(input: string, options?: SafePathOptions): boolean;

/**
 * Shared collator — the ONE ordering used by library sort and relation pickers.
 * Matches `String.prototype.localeCompare(_, "nl-NL")` (repository tests pin it).
 */
export declare const DEFAULT_LOCALE = "nl-NL";
export type SortDirection = "asc" | "desc";
export declare function createTextCollator(locale?: string): Intl.Collator;
export declare function compareText(a: string, b: string, locale?: string): number;
export declare function compareNumbers(a: number, b: number): number;
/**
 * Compares display values: strings collate, numbers order numerically,
 * empty values sort last regardless of direction (founder-friendly libraries).
 */
export declare function compareValues(a: unknown, b: unknown, direction?: SortDirection): number;
export declare function sortBy<T>(items: readonly T[], getValue: (item: T) => unknown, direction?: SortDirection): T[];

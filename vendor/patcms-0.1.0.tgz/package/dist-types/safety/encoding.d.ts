/**
 * Runtime-agnostic UTF-8/base64 codecs. Core avoids TextEncoder/atob/Buffer so
 * the same code runs in Node tests and browser bundles (no DOM lib dependency).
 */
export declare function encodeUtf8(text: string): Uint8Array;
export declare function decodeUtf8(bytes: Uint8Array): string;
export declare function decodeBase64(text: string): Uint8Array;
/** Standard padded base64 (GitHub-style frame; decode tolerates whitespace). */
export declare function encodeBase64(bytes: Uint8Array): string;

/**
 * Date formatting helpers for founder surfaces (P5.2).
 * Strictly non-ambiguous formatting per Master Plan §7:
 * dates "Tue 4 Feb", relative times "just now" / "10 minutes ago".
 */
export declare function parseDate(value: Date | string | number): Date;
/** Formats a date as "Tue 4 Feb" (or "Tue 4 Feb 2026" if not the current year). */
export declare function formatFriendlyDate(value: Date | string | number, now?: Date): string;
/** Formats relative time ("just now", "10 minutes ago", "2 hours ago", "yesterday", or "Tue 4 Feb"). */
export declare function formatRelativeTime(value: Date | string | number, now?: Date): string;

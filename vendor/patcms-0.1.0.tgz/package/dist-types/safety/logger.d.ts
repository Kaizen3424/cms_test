/**
 * Log masking + memory-only ring buffer — ADR-0002 §conditions, ADR-0009 §?,
 * INV-A05. Rules: mask classic credential KEYS (authorization/token/secret/
 * password and any `x-github-*` header) and re-mask value patterns
 * (github_pat_…, ghp_/gho_…, email addresses). The buffer is MEMORY-ONLY —
 * no persistence, no upload, ever (demonstrations surface it via a
 * user-initiated "copy diagnostics" action, never automatically).
 */
/** LogRecord stored in the ring buffer (already masked). */
export interface LogRecord {
    readonly level: LogLevel;
    readonly message: string;
    readonly data: unknown;
    readonly at: string;
}
export type LogLevel = "debug" | "info" | "warn" | "error";
/** Key-level mask check — classic credential keys and every `x-github-*` header. */
export declare function isSensitiveKey(key: string): boolean;
export declare function maskString(value: string): string;
export declare function maskData(value: unknown, depth: number): unknown;
export interface Logger {
    debug(message: string, data?: unknown): void;
    info(message: string, data?: unknown): void;
    warn(message: string, data?: unknown): void;
    error(message: string, data?: unknown): void;
    /** Snapshot of the ring buffer (oldest → newest). Memory-only by construction. */
    readonly history: readonly LogRecord[];
}
export declare function createLogger(capacity?: number): Logger;

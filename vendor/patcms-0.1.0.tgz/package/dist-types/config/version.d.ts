export declare const CONFIG_SCHEMA_VERSION: 1;

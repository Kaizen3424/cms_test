/** Strict, closed validation of JSON-safe admin config documents (ADR-0003). */
import { z } from "zod";
import type { FieldDescriptor } from "../fields/types";
import type { AdminConfig } from "./types";
export declare const fieldDescriptorSchema: z.ZodType<FieldDescriptor>;
export interface ConfigIssue {
    readonly path: string;
    readonly message: string;
}
export declare class ConfigValidationError extends Error {
    readonly issues: readonly ConfigIssue[];
    constructor(issues: readonly ConfigIssue[]);
}
/** Strict parse; unknown keys/types and semantic inconsistencies are errors. */
export declare function parseAdminConfig(value: unknown): AdminConfig;
/** Non-throwing helper for hosts that want to render config errors. */
export declare function safeParseAdminConfig(value: unknown): {
    readonly ok: true;
    readonly config: AdminConfig;
} | {
    readonly ok: false;
    readonly issues: readonly ConfigIssue[];
};

import type { AdminConfig, CollectionDefinition, ConfigDefinition, ConfigOptions, FileDefinition, FileOptions, FilesCollectionDefinition, FilesCollectionOptions, FolderCollectionDefinition, FolderCollectionOptions } from "./types";
export declare function defineCollection(options: FolderCollectionOptions): FolderCollectionDefinition;
export declare function defineFiles(options: FilesCollectionOptions): FilesCollectionDefinition;
export declare function defineFile(collectionName: string, options: FileOptions): FileDefinition;
export declare function collectionDivider(label?: string): CollectionDefinition;
export declare function defineConfig(options: ConfigOptions): ConfigDefinition;
/** Drops zod schemas and produces the strict, JSON-safe admin document. */
export declare function toAdminConfig(config: ConfigDefinition): AdminConfig;

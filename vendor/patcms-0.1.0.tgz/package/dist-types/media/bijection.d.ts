/**
 * Media path bijection — ADR-0007 §5 (INV-M01).
 *
 * Implements the bijective mapping between web-facing public media paths
 * (e.g. `/images/products/ring.jpg`) and repository-relative storage paths
 * (e.g. `public/images/products/ring.jpg`), honoring root media configurations
 * and per-collection overrides.
 *
 * All conversions run through safePath() on both read and write: traversals,
 * backslashes, encoded separators, and prefix escapes are strictly rejected.
 */
import type { AdminConfig } from "../config/types";
import type { SafePathResult } from "../safety/safe-path";
import type { MediaFolders } from "./types";
/**
 * Resolves the active MediaFolders configuration for an operation.
 * Returns collection-specific media if configured; falls back to root config.media.
 */
export declare function resolveMediaFolders(config: AdminConfig, collectionName?: string): MediaFolders;
/**
 * Converts a web-facing public media path into a repository-relative file path.
 *
 * Example:
 *   publicPath: "/images/products/ring.jpg"
 *   media: { folder: "public/images", publicFolder: "/images" }
 *   -> "public/images/products/ring.jpg"
 */
export declare function publicPathToRepoPath(publicPath: string, media: MediaFolders): SafePathResult;
/**
 * Converts a repository-relative media path into a web-facing public URL path.
 *
 * Example:
 *   repoPath: "public/images/products/ring.jpg"
 *   media: { folder: "public/images", publicFolder: "/images" }
 *   -> "/images/products/ring.jpg"
 */
export declare function repoPathToPublicPath(repoPath: string, media: MediaFolders): SafePathResult;

/**
 * Media budget math — ADR-0007 §6.
 *
 * Computes repository media economy metrics from recursive git tree entries
 * in O(N) time with zero network requests.
 *
 * Thresholds (ADR-0007 §6):
 *  - Repository media total >= 800MB (838,860,800 bytes): warning surfaced.
 *  - Repository media count >= 2,500 files: warning surfaced.
 *  - Single-file upload > 90MiB (94,371,840 bytes): client hard rejection.
 */
import type { TreeEntryTuple } from "../backend/types";
import type { MediaBudget, MediaFolders } from "./types";
export declare const WARNING_THRESHOLD_BYTES: number;
export declare const WARNING_THRESHOLD_COUNT = 2500;
export declare const CLIENT_BLOCK_BYTES: number;
/**
 * Calculates total media bytes and file counts from recursive tree entries.
 * Evaluates entries against configured repository media folders.
 */
export declare function calculateMediaBudget(treeEntries: readonly TreeEntryTuple[], media: MediaFolders | readonly MediaFolders[]): MediaBudget;
/**
 * Asserts whether a single file exceeds the 90MiB client-side upload hard block.
 */
export declare function isUploadSizeBlocked(byteLength: number): boolean;

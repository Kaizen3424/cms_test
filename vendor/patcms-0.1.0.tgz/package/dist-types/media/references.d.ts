/**
 * Referential integrity engine (`findReferences`) — ADR-0007 §5 (INV-M03).
 *
 * Recursively scans entry data structures (folder collections and single-file
 * documents) across the repository to locate all references to a media path
 * or relation slug.
 *
 * Pure function in `patcms` with zero DOM dependencies.
 */
import type { AdminConfig } from "../config/types";
import type { ReferenceLocation, ReferenceQuery } from "./types";
export interface SearchableEntry {
    readonly collection: string;
    readonly slug: string;
    readonly title?: string;
    readonly value: unknown;
}
/**
 * Searches across entries for references to a given media asset path or relation.
 */
export declare function findReferences(query: ReferenceQuery, entries: readonly SearchableEntry[], config: AdminConfig): readonly ReferenceLocation[];

/**
 * Invariant INV-M01: Media path bijection `/images/** ⇄ public/images/**`
 * and media budget calculation — ADR-0007 §5, §6.
 */
export {};

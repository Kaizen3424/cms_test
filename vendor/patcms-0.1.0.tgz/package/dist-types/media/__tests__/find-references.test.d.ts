/**
 * Test suite for the findReferences referential integrity engine (P4.2).
 *
 * Verifies cross-collection reference detection against real yve content shapes:
 *  - single-file relation reference (`home.studyProduct` -> `the-rock-no-1`)
 *  - multi-relation reference list (`collections.featuredProducts` -> `["the-rock-no-1", "karst-no-2"]`)
 *  - shared media paths (e.g. `/images/site/ing-yve-collections.jpg` in `craft.json` and `bespoke.json`)
 *  - companion alt text extraction from gallery items
 */
export {};

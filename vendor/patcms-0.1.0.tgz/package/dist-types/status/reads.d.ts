/** Binds the branch ONCE at composition time (INV-P14: branch stays data). */
import type { GitBackend } from "../backend/types";
import type { StatusReads } from "./types";
export declare function createStatusReads(backend: GitBackend, branch: string): StatusReads;

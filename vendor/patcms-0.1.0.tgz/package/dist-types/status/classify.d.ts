/**
 * Pure deploy-status classifiers — ADR-0008 P2.8 conclusion matrix.
 *
 * Check runs are primary; commit statuses are consulted only through configured
 * `deploy.contexts` and only when the check-run set has no decisive result.
 * `neutral`/`skipped` never count as success (a skipped-only set is unavailable,
 * never Live). Failure outranks a still-running sibling.
 */
import type { CheckRunsRead, CommitStatusesRead } from "../backend/types";
import type { DeployStatusCause, DeployStatusKind } from "./types";
export interface StatusDecision {
    readonly verdict: DeployStatusKind;
    readonly source: "checks" | "statuses" | "none";
    readonly detailsUrl?: string;
    readonly failureNames?: readonly string[];
    readonly cause?: DeployStatusCause;
}
/** Check-run matrix; `awaiting` means "no decisive result yet" (grace subject). */
export declare function classifyCheckRuns(read: CheckRunsRead): StatusDecision;
/**
 * Commit-statuses fallback. `contexts` is the exact allow-list; absent/empty
 * disables the source entirely (never polled by the watcher).
 */
export declare function classifyCommitStatuses(read: CommitStatusesRead, contexts: readonly string[]): StatusDecision;
/** Primary/fallback composition: a decisive check state always wins. */
export declare function decideStatus(checks: CheckRunsRead, statuses: CommitStatusesRead, contexts: readonly string[]): StatusDecision;

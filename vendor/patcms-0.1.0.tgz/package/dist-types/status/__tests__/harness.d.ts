/**
 * Deterministic seams for status-watcher tests: no real timers, no globals.
 * The watcher owns no clock — this harness proves the injection contract and
 * lets INV-D01/D03 drive grace, cadence and supersede without sleeps.
 */
import type { CheckRunsRead, CommitStatusesRead } from "../../backend/types";
import type { DeployStatusSnapshot, StatusTiming, StatusWatcher } from "../types";
export interface ScheduledPoll {
    readonly at: number;
    readonly delay: number;
    readonly task: () => void;
    cancelled: boolean;
    ran: boolean;
}
export interface StatusHarnessOptions {
    readonly sha: string;
    readonly head?: string;
    readonly contexts?: readonly string[];
    readonly timing?: Partial<StatusTiming>;
    readonly checks?: CheckRunsRead;
    readonly statuses?: CommitStatusesRead;
    readonly random?: () => number;
}
export declare function emptyChecks(): CheckRunsRead;
export declare function emptyStatuses(): CommitStatusesRead;
export interface StatusHarness {
    readonly watcher: StatusWatcher;
    readonly snapshots: readonly DeployStatusSnapshot[];
    readonly scheduled: readonly ScheduledPoll[];
    readonly delays: readonly number[];
    readonly checksReads: number;
    readonly statusesReads: number;
    readonly headReads: number;
    /** Shas the watcher actually asked about (per-sha keying truth). */
    readonly checksShas: readonly string[];
    readonly statusesShas: readonly string[];
    now(): number;
    start(): Promise<void>;
    advance(ms: number): Promise<void>;
    flush(): Promise<void>;
    active(): readonly ScheduledPoll[];
    setHead(head: string): void;
    setChecks(checks: CheckRunsRead): void;
    setStatuses(statuses: CommitStatusesRead): void;
    failHeadRead(): void;
    failChecksRead(): void;
    failStatusesRead(): void;
}
export declare function createStatusHarness(options: StatusHarnessOptions): StatusHarness;

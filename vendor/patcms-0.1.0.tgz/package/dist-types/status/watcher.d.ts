/**
 * Deploy-status watcher — ADR-0008 P2.8 appendix.
 *
 * One watcher per commit sha. All timing enters through injected `now`,
 * `schedulePoll` and `random`; the module never touches a global timer.
 * Terminal states stop; read errors degrade to `unavailable` (never `failed`);
 * the configured grace turns "no decisive run yet" into `unavailable`.
 */
import { type StatusWatcher, type StatusWatcherOptions } from "./types";
export declare function createStatusWatcher(options: StatusWatcherOptions): StatusWatcher;

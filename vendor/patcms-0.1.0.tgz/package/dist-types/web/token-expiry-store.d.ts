export interface TokenExpiryConfig {
    readonly createdAt: string;
    readonly durationDays: 30 | 60 | 90;
}
export declare function getTokenExpiryConfig(): Promise<TokenExpiryConfig | null>;
export declare function setTokenExpiryConfig(config: TokenExpiryConfig): Promise<void>;
export declare function clearTokenExpiryConfig(): Promise<void>;

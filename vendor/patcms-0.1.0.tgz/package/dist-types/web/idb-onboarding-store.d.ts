export interface OnboardingState {
    readonly pactDismissed: boolean;
    readonly tourCompleted: boolean;
    readonly firstPublishCompleted: boolean;
}
export interface OnboardingStore {
    get(): Promise<OnboardingState>;
    update(patch: Partial<OnboardingState>): Promise<OnboardingState>;
    reset(): Promise<void>;
    subscribe(listener: () => void): () => void;
}
export interface IdbOnboardingStoreOptions {
    readonly dbName?: string;
    readonly storeName?: string;
}
export declare function createIdbOnboardingStore(options?: IdbOnboardingStoreOptions): OnboardingStore;
export declare function createMemoryOnboardingStore(initial?: Partial<OnboardingState>): OnboardingStore;

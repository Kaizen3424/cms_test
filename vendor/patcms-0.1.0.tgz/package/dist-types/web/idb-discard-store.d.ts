export interface DiscardRecord {
    readonly id: string;
    readonly draftKey: string;
    readonly entryPath: string;
    readonly fieldPath: string;
    readonly discardedAt: string;
    readonly discardedValue: unknown;
    readonly formattedPreview: string;
}
export interface DiscardStore {
    record(entry: Omit<DiscardRecord, "id" | "discardedAt">): Promise<DiscardRecord>;
    list(draftKey?: string): Promise<readonly DiscardRecord[]>;
    evictStale(maxAgeMs?: number, maxRecords?: number): Promise<number>;
    clear(): Promise<void>;
}
export interface IdbDiscardStoreOptions {
    readonly dbName?: string;
    readonly storeName?: string;
    readonly maxAgeMs?: number;
    readonly maxRecords?: number;
}
export declare function createIdbDiscardStore(options?: IdbDiscardStoreOptions): DiscardStore;
export declare function createMemoryDiscardStore(options?: {
    readonly maxAgeMs?: number;
    readonly maxRecords?: number;
}): DiscardStore;

import type { TokenStore } from "../auth";
export interface IdbTokenStoreOptions {
    readonly dbName?: string;
    readonly storeName?: string;
    readonly key?: string;
}
export declare function createIdbTokenStore(options?: IdbTokenStoreOptions): TokenStore;
export declare function createSessionTokenStore(key?: string): TokenStore;

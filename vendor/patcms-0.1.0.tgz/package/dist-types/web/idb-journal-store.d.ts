export interface JournalRecord {
    readonly id: string;
    readonly commitSha: string;
    readonly entryId: string;
    readonly collectionName: string;
    readonly entryTitle: string;
    readonly path: string;
    readonly publishedAt: string;
    readonly author: string;
    readonly publicUrl?: string;
}
export interface JournalStore {
    append(record: Omit<JournalRecord, "id">): Promise<JournalRecord>;
    list(options?: {
        readonly limit?: number;
    }): Promise<readonly JournalRecord[]>;
    clear(): Promise<void>;
    subscribe(listener: () => void): () => void;
}
export interface IdbJournalStoreOptions {
    readonly dbName?: string;
    readonly storeName?: string;
    readonly maxRecords?: number;
}
export declare function createIdbJournalStore(options?: IdbJournalStoreOptions): JournalStore;
export declare function createMemoryJournalStore(maxRecords?: number): JournalStore;

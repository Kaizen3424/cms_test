import type { DraftStore } from "../drafts";
export interface IdbDraftStoreOptions {
    readonly dbName?: string;
    readonly storeName?: string;
}
export declare function createIdbDraftStore(options?: IdbDraftStoreOptions): DraftStore;
/** Test/SSR helper: empties the draft database (never touches auth). */
export declare function clearIdbDraftStore(options?: IdbDraftStoreOptions): Promise<void>;

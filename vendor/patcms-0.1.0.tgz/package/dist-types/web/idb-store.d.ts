/**
 * Shared IndexedDB schema opener (ADR-0004 "Shared IndexedDB schema" note).
 *
 * idb-keyval's `createStore(dbName, storeName)` sets `onupgradeneeded` to create
 * ITS store, but that event only fires while the database is being created. Two
 * adapters share one database (`auth` for the PAT — ADR-0002, `drafts` for the
 * editor — ADR-0004), so whichever opened second got `NotFoundError` on its
 * first transaction. This module opens the database once, declares every store
 * up front, and bumps the version when an existing database lacks one.
 *
 * Pure browser adapter: core's Node-safe entry never imports it.
 */
import type { UseStore } from "idb-keyval";
/**
 * The object stores the default `mycms` database owns. A new store is added
 * HERE in the same change that starts using it (ADR-0004 note).
 */
export declare const MYCMS_IDB_STORES: readonly ["auth", "drafts"];
/**
 * Opens (and caches) `dbName` with at least `storeNames`. Calls are additive:
 * the schema is the union of every store any adapter has asked for.
 */
export declare function openMycmsDatabase(dbName?: string, storeNames?: readonly string[]): Promise<IDBDatabase>;
/**
 * idb-keyval `UseStore` bound to one store of the shared database. The store is
 * added to the schema automatically, so a custom store name is always creatable.
 */
export declare function createSharedStore(dbName: string, storeName: string): UseStore;
/** Closes every cached connection (tests / teardown). */
export declare function closeMycmsDatabases(): Promise<void>;

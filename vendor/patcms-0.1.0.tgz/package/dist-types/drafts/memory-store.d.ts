/** In-memory draft store — the client default. Pass an IDB store for persistence. */
import type { DraftStore } from "./index";
export declare function createMemoryDraftStore(): DraftStore;

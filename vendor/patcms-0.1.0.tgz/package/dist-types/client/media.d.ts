import type { AdminConfig } from "../config/types";
import type { SearchableEntry } from "../media/references";
import type { ReferenceLocation } from "../media/types";
import type { ClientCache } from "./cache";
import type { RepoReader } from "./repo";
import type { MediaAPI, MediaBlob, MediaDeleteOptions, MediaDeleteResult, MediaFile, MediaListOptions, MediaUploadInput, UploadOptions } from "./types";
export interface MediaClientOptions {
    readonly config: AdminConfig;
    readonly repo: RepoReader;
    readonly cache: ClientCache;
    readonly searchable: () => Promise<readonly SearchableEntry[]>;
    readonly onAuthExpired: () => void;
}
export declare class MediaClient implements MediaAPI {
    #private;
    constructor(options: MediaClientOptions);
    list(options?: MediaListOptions): Promise<MediaFile[]>;
    get(publicPath: string, options?: MediaListOptions): Promise<MediaBlob>;
    upload(input: MediaUploadInput, options?: UploadOptions): Promise<MediaFile>;
    delete(publicPath: string, options?: MediaDeleteOptions): Promise<MediaDeleteResult>;
    restore(trashPath: string, options?: {
        message?: string;
    }): Promise<MediaFile>;
    references(publicPath: string, options?: MediaListOptions): Promise<readonly ReferenceLocation[]>;
    publicPath(repoPath: string, options?: MediaListOptions): string;
    repoPath(publicPath: string, options?: MediaListOptions): string;
}

import type { CommitChangeSet, GitBackend, TreeRead } from "../backend/types";
import type { BackendWriteError } from "../backend/write-errors";
import { type SaveVerdict } from "../pipeline/save-driver";
import type { ClientCache } from "./cache";
export declare class RepoReader {
    #private;
    constructor(backend: GitBackend, branch: string, cache: ClientCache, requireToken: () => void);
    tree(): Promise<TreeRead>;
    readFile(path: string, blobSha: string): Promise<Uint8Array>;
    readBlob(sha: string): Promise<Uint8Array>;
    save(changes: CommitChangeSet, message?: string, onAfterWriteFailure?: (error: BackendWriteError) => void): Promise<SaveVerdict>;
}

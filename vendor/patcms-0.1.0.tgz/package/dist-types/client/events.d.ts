/** Small typed event bus. Listeners are UI notifications, never a second cache. */
export type EventListener<T> = (payload: T) => void;
export type Unsubscribe = () => void;
export declare class EventBus<M extends object> {
    #private;
    on<K extends keyof M>(event: K, handler: EventListener<M[K]>): Unsubscribe;
    emit<K extends keyof M>(event: K, payload: M[K]): void;
    clear(): void;
}

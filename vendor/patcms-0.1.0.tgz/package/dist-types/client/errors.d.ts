/**
 * One error type for every expected operational failure.
 *
 * Rules: a save conflict is a VALUE, not an exception; a validation failure is
 * a value from `entries.validate` but an exception from `entries.save`; no
 * message ever contains a token; the original backend error rides on `cause`.
 */
import type { ParseIssue } from "../fields/parse";
export type CMSErrorCode = "AUTH_REQUIRED" | "AUTH_EXPIRED" | "FORBIDDEN" | "NOT_FOUND" | "CONFLICT" | "RATE_LIMIT" | "NETWORK" | "VALIDATION" | "UNSUPPORTED" | "INVALID_CONFIG" | "UNKNOWN";
export interface CMSErrorOptions {
    readonly status?: number;
    /** ISO timestamp (or GitHub's raw reset value) for a rate-limited retry. */
    readonly retryAt?: string;
    readonly issues?: readonly ParseIssue[];
    readonly cause?: unknown;
}
export declare class CMSError extends Error {
    readonly name = "CMSError";
    readonly code: CMSErrorCode;
    readonly status: number | undefined;
    readonly retryAt: string | undefined;
    readonly issues: readonly ParseIssue[] | undefined;
    constructor(code: CMSErrorCode, message: string, options?: CMSErrorOptions);
}
export declare function isCMSError(value: unknown): value is CMSError;
/** Normalises anything thrown inside the client into a `CMSError`. */
export declare function toCMSError(error: unknown): CMSError;

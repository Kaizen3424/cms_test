/**
 * Auth namespace — PAT lifecycle with a capability probe on every sign-in.
 *
 * A pre-set `token` seeds the client WITHOUT a network call, so constructing a
 * client for a script costs nothing; call `verify()` when capabilities matter.
 */
import type { TokenStore } from "../auth";
import type { FetchLike } from "../composition";
import type { AuthAPI, AuthStatus, RepositoryTarget, Session, SignInOptions } from "./types";
export interface AuthControllerOptions {
    readonly repository: RepositoryTarget;
    readonly tokenStore: TokenStore;
    readonly fetch: FetchLike;
}
export declare class AuthController implements AuthAPI {
    #private;
    constructor(options: AuthControllerOptions);
    get status(): AuthStatus;
    get session(): Session | undefined;
    /** Transport-only read. Never expose this on the public `CMS` object. */
    get currentToken(): string | undefined;
    get isSignedIn(): boolean;
    /** Pre-set token: no probe, therefore no network request at construction. */
    seed(token: string): void;
    signIn(token: string, options?: SignInOptions): Promise<Session>;
    restore(): Promise<Session | undefined>;
    verify(): Promise<Session>;
    signOut(): Promise<void>;
    /**
     * A write failed with 401: the token is dead. Wipe it (and any persisted
     * copy) without waiting for the store, then surface `signedOut` to the host.
     */
    markExpired(): void;
    onChange(listener: (status: AuthStatus) => void): () => void;
}
/** Default store: memory-only, so a token never outlives the page by accident. */
export declare function defaultTokenStore(): TokenStore;

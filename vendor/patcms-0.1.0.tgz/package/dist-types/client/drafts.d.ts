/**
 * Drafts — optional local persistence for unsaved edits.
 *
 * The default store is in-memory; `patcms/web` exports an IndexedDB store for
 * hosts that want drafts to survive a reload. Keys follow the draft-key law
 * `${owner}/${repo}/${collection}/${slug}`, so staged media tiles stored by a
 * host under the same prefix never collide with entry drafts.
 */
import type { DraftStore } from "../drafts";
import type { Draft, DraftsAPI, Entry, EntryValue } from "./types";
export interface DraftsClientOptions {
    readonly store: DraftStore;
    /** `${owner}/${repo}` — the namespace every key is scoped to. */
    readonly namespace: string;
}
export declare class DraftsClient implements DraftsAPI {
    #private;
    constructor(options: DraftsClientOptions);
    save(entry: Entry, value: EntryValue): Promise<void>;
    get(entry: Pick<Entry, "collection" | "slug">): Promise<Draft | undefined>;
    list(collection?: string): Promise<readonly Draft[]>;
    delete(entry: Pick<Entry, "collection" | "slug">): Promise<void>;
}

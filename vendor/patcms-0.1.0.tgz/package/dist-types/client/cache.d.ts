/**
 * Client cache — one tree snapshot per head, entries keyed by path + blob SHA,
 * blobs keyed by content SHA. There is no background refresh: a host calls
 * `cms.refresh()` on focus or on a timer it owns.
 */
import type { TreeRead } from "../backend/types";
import type { Entry } from "./types";
export declare class ClientCache {
    #private;
    get headSha(): string | undefined;
    getTree(headSha: string): TreeRead | undefined;
    setTree(headSha: string, tree: TreeRead): void;
    getEntry(path: string, sha: string): Entry | undefined;
    putEntry(entry: Entry): void;
    dropEntry(path: string): void;
    getBlob(sha: string): Uint8Array | undefined;
    putBlob(sha: string, bytes: Uint8Array): void;
    clear(): void;
}

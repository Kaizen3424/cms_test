/**
 * `createCMS()` — the one entry point a host needs.
 *
 * Construction is offline: a `token` seeds the client without a probe, and no
 * network call happens until an entry or media operation runs. Signing in with
 * `auth.signIn(token)` probes capabilities first and throws `CMSError` when the
 * token cannot write to the repository.
 */
import type { TokenStore } from "../auth";
import type { FetchLike } from "../composition";
import type { AdminConfig, ConfigDefinition } from "../config/types";
import type { DraftStore } from "../drafts";
import type { CMS, RepositoryTarget } from "./types";
export interface CreateCMSOptions {
    /** Output of `defineConfig(...)`, or an already-projected `AdminConfig`. */
    readonly config: ConfigDefinition | AdminConfig;
    readonly repository: RepositoryTarget;
    /** Pre-set PAT. No probe runs until `auth.verify()`; useful for scripts. */
    readonly token?: string;
    /** Token persistence. Defaults to memory-only. */
    readonly tokenStore?: TokenStore;
    /** Draft persistence. Defaults to memory-only; `patcms/web` adds IndexedDB. */
    readonly drafts?: DraftStore;
    /** Custom transport (tests, proxies). Defaults to `globalThis.fetch`. */
    readonly fetch?: FetchLike;
    /** Called after a 401 write wiped the session. */
    readonly onAuthExpired?: () => void;
}
export declare function createCMS(options: CreateCMSOptions): CMS;

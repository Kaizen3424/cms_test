import type { AdminConfig } from "../config/types";
import type { SearchableEntry } from "../media/references";
import type { ClientCache } from "./cache";
import type { RepoReader } from "./repo";
import type { CreateOptions, DeleteOptions, DeleteResult, EntriesAPI, Entry, EntryStub, EntrySummary, EntryValue, ListOptions, SaveOptions, SaveResult, ValidationResult } from "./types";
export interface EntriesClientOptions {
    readonly config: AdminConfig;
    readonly repo: RepoReader;
    readonly cache: ClientCache;
    /** Called when GitHub rejects the token mid-write; the client signs out. */
    readonly onAuthExpired: () => void;
}
export declare class EntriesClient implements EntriesAPI {
    #private;
    constructor(options: EntriesClientOptions);
    list(collection: string, options?: ListOptions): Promise<EntrySummary[]>;
    listPaths(collection: string): Promise<EntryStub[]>;
    get(collection: string, slug: string): Promise<Entry>;
    create(collection: string, value: EntryValue, options?: CreateOptions): Promise<SaveResult>;
    save(entry: Entry, value: EntryValue, options?: SaveOptions): Promise<SaveResult>;
    delete(entry: Entry, options?: DeleteOptions): Promise<DeleteResult>;
    validate(entry: Entry, value: EntryValue): Promise<ValidationResult>;
    /**
     * Every entry value in the repository, for referential-integrity scans.
     * Internal to the client (media delete/restore); not part of `EntriesAPI`.
     */
    searchable(): Promise<readonly SearchableEntry[]>;
    path(collection: string, slug: string): string;
    slugFromValue(collection: string, value: EntryValue): string;
}

/**
 * Recorded HTTP fixture replay transport — ADR-0005 P2.11 addendum.
 *
 * Implements an in-memory FetchLike transport that replays HTTP interactions
 * recorded from a GitHub repository or the reference FakeGithubServer.
 * Uses a Keyed-Endpoint FIFO Queue matching strategy:
 * - Match keys incorporate HTTP method, canonical pathname/query, If-None-Match ETag,
 *   and SHA-1 of request body.
 * - Monotonic consecutive calls (e.g. repeated getRef) pop responses FIFO.
 * - Concurrent requests (e.g. parallel blob creation) are disambiguated by body hash.
 * - Zero external runtime dependencies; purely in-memory.
 */
import type { FetchLike } from "../../composition";
export interface RecordedRequest {
    readonly method: string;
    readonly url: string;
    readonly headers?: Record<string, string>;
    readonly body?: unknown;
}
export interface RecordedResponse {
    readonly status: number;
    readonly statusText?: string;
    readonly headers: Record<string, string>;
    readonly body?: unknown;
}
export interface RecordedInteraction {
    readonly request: RecordedRequest;
    readonly response: RecordedResponse;
}
export interface RecordedTapeMeta {
    readonly schemaVersion: 1;
    readonly recordedAt: string;
    readonly owner: string;
    readonly repo: string;
    readonly branch: string;
    readonly source: "sandbox" | "synthetic";
    readonly description?: string;
}
export interface RecordedTape {
    readonly schemaVersion: 1;
    readonly meta: RecordedTapeMeta;
    readonly interactions: readonly RecordedInteraction[];
}
export interface ReplayFetchOptions {
    /** Override the owner parameter in URLs during replay (defaults to tape.meta.owner). */
    readonly owner?: string;
    /** Override the repo parameter in URLs during replay (defaults to tape.meta.repo). */
    readonly repo?: string;
}
export type ReplayFetch = FetchLike & {
    /** Returns the total count of unconsumed interactions remaining across all queues. */
    readonly remainingCount: () => number;
    /** True when all recorded interactions have been consumed. */
    readonly isDrained: () => boolean;
    /** List of remaining match keys with their pending queue counts. */
    readonly pendingKeys: () => readonly {
        key: string;
        count: number;
    }[];
    /** Resets queues back to the original tape state. */
    readonly reset: () => void;
};
/** Recursively canonicalizes JSON values with sorted object keys. */
export declare function canonicalizeJson(val: unknown): string;
/** Normalizes a request body into a canonical string for SHA-1 hashing. */
export declare function normalizeBodyString(body: unknown): string;
/** Normalizes request path + query, parameterizing owner and repo. */
export declare function normalizeRequestPath(urlStr: string, owner?: string, repo?: string): string;
/** Builds the composite match key for an interaction. */
export declare function buildMatchKey(method: string, url: string, headers: Record<string, string> | undefined, body: unknown, owner?: string, repo?: string): Promise<string>;
/**
 * Creates an in-memory FetchLike implementation that deterministically
 * replays recorded interactions from a RecordedTape.
 */
export declare function createReplayFetch(tape: RecordedTape, options?: ReplayFetchOptions): Promise<ReplayFetch>;

/**
 * GithubBackend — hand-rolled fetch transport over the `FetchLike` seam.
 * ADR-0005 reads only in P1: refs, recursive trees, contents/blobs, tree diffs.
 * The token appears ONLY in the Authorization header; never in a URL.
 */
import type { CheckRunsRead, CommitChangeSet, CommitOptions, CommitResult, CommitStatusesRead, GitBackend, GitBackendCapabilities, ReadFileOptions, ReadFileResult, ReadTreeOptions, ReadTreeResult, Ref, TreeEntryTuple } from "../../backend/types";
import type { FetchLike } from "../../composition";
export interface GithubBackendOptions {
    readonly owner: string;
    readonly repo: string;
    readonly token: string | (() => string | undefined);
    readonly fetch: FetchLike;
    /** API origin override (tests/proxies); defaults to https://api.github.com. */
    readonly baseUrl?: string;
}
export declare class GithubBackend implements GitBackend {
    #private;
    readonly capabilities: GitBackendCapabilities;
    constructor(options: GithubBackendOptions);
    /** Updates the in-memory access key for in-place re-authentication (INV-A01). */
    setToken(token: string): void;
    getRef(branch: string): Promise<Ref>;
    readTree(branch: string, commitSha: string, options?: ReadTreeOptions): Promise<ReadTreeResult>;
    readFile(branch: string, path: string, blobSha: string, options?: ReadFileOptions): Promise<ReadFileResult>;
    listChangedFiles(branch: string, baseSha: string, headSha: string): Promise<ReadonlyMap<string, TreeEntryTuple>>;
    readCheckRuns(branch: string, sha: string): Promise<CheckRunsRead>;
    readCommitStatuses(branch: string, sha: string): Promise<CommitStatusesRead>;
    commitChanges(changes: CommitChangeSet, baseHeadSha: string, branch: string, options?: CommitOptions): Promise<CommitResult>;
    readBlob(sha: string): Promise<Uint8Array>;
}
/** Encodes each branch segment, including `+` (INV-P14 branch-name test). */
export declare function encodeBranch(branch: string): string;
export type { RecordedInteraction, RecordedRequest, RecordedResponse, RecordedTape, RecordedTapeMeta, ReplayFetch, ReplayFetchOptions, } from "./recorded-replay";
export { buildMatchKey, canonicalizeJson, createReplayFetch, normalizeBodyString, normalizeRequestPath, } from "./recorded-replay";

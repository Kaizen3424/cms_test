/**
 * Backend contract suite — ADR-0001.
 *
 * The SAME suite every backend implementation must pass (GithubBackend,
 * reference-fixture-backend exemplar, Stage-B GitLab — and the playground's
 * FakeGithub). Checks are self-contained and sequential; write checks run
 * AFTER read checks and leave HEAD in a coherent state.
 */
import type { GitBackend } from "../../backend/types";
export interface ContractContext {
    readonly backend: GitBackend;
    /** Branch is data (INV-P14); the suite never hard-codes a branch name. */
    readonly branch: string;
    readonly expectedPaths: readonly string[];
    readonly expectedFileBytes?: Uint8Array;
}
export interface ContractCheck {
    readonly name: string;
    run(ctx: ContractContext): Promise<void>;
}
export interface ContractSuite {
    readonly name: "core-contract-suite";
    readonly checks: readonly ContractCheck[];
}
export interface ContractFailure {
    readonly name: string;
    readonly error: unknown;
}
export interface ContractReport {
    readonly passed: number;
    readonly failures: readonly ContractFailure[];
    readonly ok: boolean;
}
export interface ContractRunOptions {
    readonly branch?: string;
    readonly expectedPaths?: readonly string[];
    readonly expectedFileBytes?: Uint8Array;
}
/** Marks and freezes a check list — the suite cannot grow silently at runtime. */
export declare function defineContractSuite(checks: readonly ContractCheck[]): ContractSuite;
/** Executes checks sequentially against one backend implementation. */
export declare function runContractSuite(backend: GitBackend, suite: ContractSuite, options?: ContractRunOptions): Promise<ContractReport>;
/**
 * Shape check: capabilities must be the exhaustive boolean object and the
 * read/write methods must exist.
 */
export declare const SHAPE_CHECK: ContractCheck;
export declare const READ_TREE_CHECK: ContractCheck;
export declare const BLOB_READ_CHECK: ContractCheck;
export declare const READ_FILE_CHECK: ContractCheck;
export declare const ETAG_CHECK: ContractCheck;
export declare const EMPTY_DIFF_CHECK: ContractCheck;
/**
 * Status reads are required methods gated by `capabilities.commitStatus`
 * (ADR-0005 P2.8 addendum): truthful ok-shape when true, `unsupported` when
 * false. Status data itself is scenario-owned; the suite checks the contract.
 */
export declare const STATUS_READ_CHECK: ContractCheck;
/** Transactional green path: one commit, exact diff, byte-exact read-back. */
export declare const WRITE_COMMIT_CHECK: ContractCheck;
/** CAS law: a stale-base commit is refused; HEAD never moves backwards. */
export declare const WRITE_CAS_CHECK: ContractCheck;
export declare const CORE_CONTRACT_SUITE: ContractSuite;

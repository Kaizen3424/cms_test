/**
 * Lease carriers — the transport under the pure `createSaveLease` (ADR-0004
 * §cross-tab lease). BroadcastChannel is the primary carrier; the storage-event
 * fallback serves engines without BC (Safari <15.4). Both carry ONLY the lease
 * payload — never content, never token (INV-P13).
 */
import type { LeaseCarrier } from "../../pipeline/save-lease";
/** Minimal listener registry seam — globalThis in browsers, EventTarget in tests. */
interface EventSource {
    addEventListener(type: "storage", listener: (event: StorageEvent) => void): void;
    removeEventListener(type: "storage", listener: (event: StorageEvent) => void): void;
}
/** BroadcastChannel carrier — same-origin tabs, lowest latency. */
export declare function createBroadcastCarrier(channelName?: string): LeaseCarrier;
export interface StorageCarrierOptions {
    readonly storage: Storage;
    /** localStorage slot prefix for wire messages. */
    readonly slotKey?: string;
    /**
     * Listener registry — globalThis in browsers. Node tests inject an
     * EventTarget (and fire storage-shaped events at it) to exercise the
     * event side without a browser.
     */
    readonly events?: EventSource;
}
/**
 * storage-event carrier — writes the wire message into a localStorage slot;
 * the `storage` event fires in OTHER tabs (never self), which is exactly the
 * cross-tab visibility the fallback needs. Self-echo is unnecessary: the pure
 * lease keeps its own view for its own posts.
 */
export declare function createStorageCarrier(options: StorageCarrierOptions): LeaseCarrier;
/** Feature-detected carrier choice (BC primary; storage fallback second). */
export declare function createAutoCarrier(): LeaseCarrier;
export {};

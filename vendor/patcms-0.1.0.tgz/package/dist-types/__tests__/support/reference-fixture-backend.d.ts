/**
 * Reference-fixture backend — ADR-0009 exemplar 2.
 *
 * Zero-network GitBackend over fixture trees. Its acceptance gate is passing
 * the SAME shared contract suite as GithubBackend (ADR-0009 §4). P1 implements
 * the read surface; write plumbing stays a typed refusal until P2.
 */
import type { CheckRunsRead, CommitChangeSet, CommitOptions, CommitResult, CommitStatusesRead, GitBackend, GitBackendCapabilities, ReadFileOptions, ReadFileResult, ReadTreeOptions, ReadTreeResult, Ref, TreeEntryTuple } from "../../backend/types";
/** Typed refusal for unimplemented plumbing — callers switch on `code`. */
export declare class ContractStubNotImplementedError extends Error {
    readonly name = "ContractStubNotImplementedError";
    /** `readonly code` as a literal to keep the failure class machine-matchable. */
    readonly code = "STUB_NOT_IMPLEMENTED";
    constructor(what: string);
}
export interface FixtureFile {
    readonly bytes: Uint8Array;
    readonly sha: string;
    readonly etag?: string;
}
export interface FixtureRepoSpec {
    /** Head commit sha of the fixture tree (data, not a code literal). */
    readonly headSha: string;
    readonly treeSha?: string;
    readonly etag?: string;
    readonly capabilities?: Partial<GitBackendCapabilities>;
    readonly files?: ReadonlyMap<string, FixtureFile>;
}
/** Convenience builder for text fixtures (UTF-8 bytes, explicit blob sha). */
export declare function textFixtureFile(text: string, sha: string, etag?: string): FixtureFile;
export declare class FixtureBackend implements GitBackend {
    #private;
    constructor(spec: FixtureRepoSpec);
    /** Test hook for future ref-state plumbing (P1/P2). */
    setBranchHead(branch: string, sha: string): void;
    /** Test hook: register a tree snapshot by commit sha. */
    setSnapshot(sha: string, files: ReadonlyMap<string, FixtureFile>): void;
    get capabilities(): GitBackendCapabilities;
    getRef(branch: string): Promise<Ref>;
    readCheckRuns(branch: string, sha: string): Promise<CheckRunsRead>;
    readCommitStatuses(branch: string, sha: string): Promise<CommitStatusesRead>;
    readTree(branch: string, commitSha: string, options?: ReadTreeOptions): Promise<ReadTreeResult>;
    readFile(branch: string, path: string, blobSha: string, options?: ReadFileOptions): Promise<ReadFileResult>;
    readBlob(sha: string): Promise<Uint8Array>;
    listChangedFiles(_branch: string, baseSha: string, headSha: string): Promise<ReadonlyMap<string, TreeEntryTuple>>;
    commitChanges(changes: CommitChangeSet, baseHeadSha: string, branch: string, options?: CommitOptions): Promise<CommitResult>;
}

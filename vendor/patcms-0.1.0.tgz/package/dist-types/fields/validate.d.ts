/**
 * Strict-save validator (P1 read-side surface) + safe untouched composition.
 * Parse stays lenient; save refuses any entry with error-level issues and
 * preserves unmodeled keys verbatim through JSON-Pointer composition.
 */
import type { JsonValue } from "../safety/untrusted-json";
import type { ParseEntryOptions, ParseIssue } from "./parse";
export interface RelationServices {
    readonly hasEntry?: (collection: string, value: string) => boolean | Promise<boolean>;
}
export interface EntryValidationOptions extends ParseEntryOptions {
    readonly services?: RelationServices;
}
export type EntryValidationResult = {
    readonly ok: true;
    readonly value: Readonly<Record<string, unknown>>;
    readonly untouched: Readonly<Record<string, JsonValue>>;
} | {
    readonly ok: false;
    readonly issues: readonly ParseIssue[];
};
export declare function validateEntryForSave(options: EntryValidationOptions): Promise<EntryValidationResult>;
/**
 * Clones the parsed value and re-attaches untouched raw keys at their exact
 * JSON-Pointer paths. No Object.assign / recursive merge; every key is copied
 * explicitly and dangerous keys are refused.
 */
export declare function mergeUntouched(value: Readonly<Record<string, unknown>>, untouched: Readonly<Record<string, JsonValue>>): Record<string, unknown>;

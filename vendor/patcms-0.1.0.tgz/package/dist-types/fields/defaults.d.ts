/**
 * New-entry default folding — ported from the reference admin
 * (`editor/template-clone.ts`) so a host building its own panel does not have
 * to reimplement it.
 *
 * Law: `parseEntry` NEVER injects defaults (they are metadata); only a brand
 * new entry materialises them. A list that is `required`, or that already has
 * items, is padded to its `min` with renderable starter items; an optional list
 * with no value stays absent so optional validation still passes.
 */
import type { FieldDescriptor } from "./types";
/** Populates defaults leaf-first into `target` (mutated in place). */
export declare function foldFieldDefaults(fields: readonly FieldDescriptor[], target: Record<string, unknown>): void;
/** Creates the initial value for a blank entry in a folder collection. */
export declare function createBlankEntryValue(fields: readonly FieldDescriptor[]): Record<string, unknown>;

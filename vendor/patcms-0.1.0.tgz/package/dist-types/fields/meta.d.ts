/** Reads/writes CMS metadata carried on zod schemas via zod 4 `.meta()`. */
import { z } from "zod";
import type { FieldMeta } from "./types";
export declare const CMS_META_KEY = "mycms";
export declare function setFieldMeta<T extends z.ZodType>(schema: T, meta: FieldMeta): T;
export declare function getFieldMeta(schema: z.ZodType): FieldMeta | undefined;
/** Removes optional/nullable/default/readonly wrappers to reach the CMS schema. */
export declare function unwrapFieldSchema(schema: z.ZodType): z.ZodType;

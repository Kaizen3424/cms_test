import type { FieldDescriptor } from "../types";
export declare const media: {
    readonly folder: "public/images";
    readonly publicFolder: "/images";
};
export declare const productFields: readonly FieldDescriptor[];
export declare function cleanRaw(): Record<string, unknown>;
export declare function driftRaw(): Record<string, unknown>;

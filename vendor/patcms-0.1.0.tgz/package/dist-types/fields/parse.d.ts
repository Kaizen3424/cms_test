/**
 * Lenient read parser (ADR-0003 §3): returns `{value, issues, untouched}`.
 * It NEVER throws on bad content and NEVER injects defaults — missing optional
 * keys stay missing, hidden defaults remain metadata for the new-entry fold.
 */
import type { MediaFolders } from "../config/types";
import type { JsonValue } from "../safety/untrusted-json";
import type { FieldDescriptor } from "./types";
export type ParseIssueCode = "TYPE_MISMATCH" | "MISSING_REQUIRED" | "INVALID_OPTION" | "OUT_OF_RANGE" | "PATTERN_MISMATCH" | "INVALID_DATE" | "INVALID_PATH" | "LIST_TOO_SHORT" | "LIST_TOO_LONG" | "VIRTUAL_KEY_IGNORED" | "UNMODELED_KEY" | "UNKNOWN_FIELD_TYPE" | "RELATION_UNKNOWN" | "RELATION_CHECK_FAILED";
export interface ParseIssue {
    readonly path: string;
    readonly code: ParseIssueCode;
    readonly message: string;
    readonly severity: "error" | "warning";
}
export interface ParsedEntry {
    readonly value: Readonly<Record<string, unknown>>;
    readonly issues: readonly ParseIssue[];
    /** JSON Pointer → raw value for keys the config does not model. */
    readonly untouched: Readonly<Record<string, JsonValue>>;
}
export interface ParseEntryOptions {
    readonly fields: readonly FieldDescriptor[];
    readonly raw: unknown;
    readonly filePath: string;
    readonly media?: MediaFolders;
}
export declare function parseEntry(options: ParseEntryOptions): ParsedEntry;

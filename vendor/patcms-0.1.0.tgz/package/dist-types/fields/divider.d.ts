/** Field-level divider decoration (no stored value). */
import type { DividerDeclaration } from "./types";
export declare function divider(options: {
    readonly before: string;
    readonly label?: string;
}): DividerDeclaration;

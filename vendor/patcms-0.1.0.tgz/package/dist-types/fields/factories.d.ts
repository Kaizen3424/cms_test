/**
 * Zod-first factory set (ADR-0003). Each factory returns a zod schema carrying
 * CMS metadata via `.meta({mycms: ...})`; `required:false` wraps with `.optional()`
 * and `default` stays METADATA ONLY (parse never injects it).
 */
import { z } from "zod";
import type { FieldMeta, FieldWidth, SelectOption, StringFormat } from "./types";
export interface BaseFieldOptions {
    readonly label: string;
    readonly hint?: string;
    readonly required?: boolean;
    readonly defaultValue?: unknown;
    readonly width?: FieldWidth;
}
export interface StringFieldOptions extends BaseFieldOptions {
    readonly format?: StringFormat;
    readonly minLength?: number;
    readonly maxLength?: number;
    readonly pattern?: RegExp;
}
export interface TextFieldOptions extends BaseFieldOptions {
    readonly minLength?: number;
    readonly maxLength?: number;
}
export interface NumberFieldOptions extends BaseFieldOptions {
    readonly int?: boolean;
    readonly min?: number;
    readonly max?: number;
}
export type BooleanFieldOptions = BaseFieldOptions;
export interface SelectFieldOptions extends BaseFieldOptions {
    readonly options: readonly (string | SelectOption)[];
    readonly multiple?: boolean;
}
export interface DatetimeFieldOptions extends BaseFieldOptions {
    readonly dateOnly?: boolean;
}
export interface ListFieldOptions extends BaseFieldOptions {
    readonly fields?: Readonly<Record<string, z.ZodType>>;
    readonly field?: {
        readonly name: string;
        readonly schema: z.ZodType;
    };
    readonly min?: number;
    readonly max?: number;
    readonly summary?: string;
}
export interface ObjectFieldOptions extends BaseFieldOptions {
    readonly fields: Readonly<Record<string, z.ZodType>>;
}
export interface ImageFieldOptions extends BaseFieldOptions {
    readonly pattern?: RegExp;
    readonly extensions?: readonly string[];
}
export interface RelationFieldOptions extends BaseFieldOptions {
    readonly collection: string;
    readonly multiple?: boolean;
    readonly valueField?: string;
    readonly displayFields?: readonly string[];
    readonly searchFields?: readonly string[];
}
export interface HiddenFieldOptions extends BaseFieldOptions {
    readonly siteEffect?: string;
}
export type SlugFieldOptions = Pick<BaseFieldOptions, "label" | "hint" | "width">;
export declare function defineField<T extends z.ZodType>(schema: T, meta: FieldMeta): T;
export declare function string(options: StringFieldOptions): z.ZodType<string>;
export declare function text(options: TextFieldOptions): z.ZodType<string>;
export declare function number(options: NumberFieldOptions): z.ZodType<number>;
export declare function boolean(options: BooleanFieldOptions): z.ZodType<boolean>;
export declare function select(options: SelectFieldOptions): z.ZodType<string | string[]>;
export declare function datetime(options: DatetimeFieldOptions): z.ZodType<string>;
export declare function image(options: ImageFieldOptions): z.ZodType<string>;
export declare function relation(options: RelationFieldOptions): z.ZodType<string | string[]>;
export declare function hidden(options: HiddenFieldOptions): z.ZodType<unknown>;
export declare function slug(options?: SlugFieldOptions): z.ZodType<string | undefined>;
export declare function list(options: ListFieldOptions): z.ZodType<unknown[]>;
export declare function object(options: ObjectFieldOptions): z.ZodType<Record<string, unknown>>;

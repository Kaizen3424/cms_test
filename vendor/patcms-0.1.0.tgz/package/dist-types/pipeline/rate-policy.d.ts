/**
 * Rate & concurrency policy — INV-N01 (ADR-0005 rate math + secondary limits).
 *
 * Rules in force:
 * - Writes pool at ≤5 concurrent transport calls (createBlob gate note).
 * - `Retry-After` and `X-RateLimit-Reset` are honored VERBATIM into typed
 *   errors; primary exhaustion surfaces a reset countdown instead of failing.
 * - Resume is EVENT-driven: timers schedule a wake, never busy-poll (the
 *   state machine in C.3 consumes `RatePauseSignal`).
 */
/** Concurrency gate: FIFO order, at most `max` tasks in flight at once. */
export interface ConcurrencyLimiter {
    run<T>(task: () => Promise<T>): Promise<T>;
    readonly active: number;
    readonly queued: number;
}
export declare function createConcurrencyLimiter(max: number): ConcurrencyLimiter;
/** Rate facts carried by typed RATE_LIMIT errors (BackendWriteError/ReadError). */
export interface RateDescriptor {
    readonly status?: number;
    readonly retryAfter?: string;
    readonly resetAt?: string;
}
/** Parse numeric-or-HTTP-date Retry-After → wait milliseconds. */
export declare function parseRetryAfter(descriptor: RateDescriptor, now: () => number): number | null;
/** X-RateLimit-Reset epoch seconds → wait milliseconds (primary exhaustion). */
export declare function parseRateWindowReset(descriptor: RateDescriptor, now: () => number): number | null;
/**
 * The longest slot this descriptor asks us to stay quiet for. `null` = no
 * rate guidance (saving may retry immediately under policy backoff, not here).
 */
export declare function describeRatePause(descriptor: RateDescriptor, now: () => number): number | null;
/**
 * Event-driven resume seam (INV-N01): a wake callback fires once after the
 * window; injections keep tests deterministic without real timers. The state
 * machine (C.3) owns how many resumes it allows.
 */
export declare function createRateResume(waitMs: number, wake: () => void): void;

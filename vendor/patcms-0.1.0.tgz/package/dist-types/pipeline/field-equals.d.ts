/**
 * `fieldEquals` — VALUE-domain equality (ADR-0004 appendix).
 *
 * Dirty decisions are made against VALUES, never bytes:
 * - strings are codepoint-exact (`é` vs `e\u0301` differ),
 * - records ignore author key ORDER (reformatting is not an edit),
 * - arrays are order-significant and compared per index ("lists per item").
 */
export declare function fieldEquals(left: unknown, right: unknown): boolean;

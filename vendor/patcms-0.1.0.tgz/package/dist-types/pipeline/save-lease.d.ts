/**
 * Save lease — ADR-0004 §cross-tab lease + C.3 operational pins (INV-P13):
 * BroadcastChannel alone is not a lease. Token + heartbeat + TTL with silent
 * steal; the stealer MUST run a full rebaseline (never a blind re-dispatch).
 * The lease is UX serialization ONLY — the FF/CAS invariant (INV-P01) remains
 * the sole correctness mechanism.
 *
 * Pure over an injected `LeaseCarrier` (message bus) + clock, so Node tests
 * exercise the exact browser behavior; the browser carriers (BroadcastChannel,
 * storage-event fallback for engines without BC) live in `core/web`.
 *
 * Model per key: `ourExpiry` (our hold's epoch expiry) and `foreignClaim`
 * (the latest foreign claim observed) + their stamps (`ourHoldStamp` = the
 * post-time of the claim that ESTABLISHED our hold, kept across renewals;
 * `foreignSeenAt` = first observation of the tracked foreign claim — a
 * renewal by the SAME holder keeps it, so a heart-beating hold stays
 * "pre-existing" to later claimants). Deterministic tie-break: the SMALLER
 * holderId wins a CONTEMPORANEOUS fresh-claim race (claims first observed
 * within the settle window). A claim that PREDATES our post is a live hold:
 * acquire refuses it regardless of id, and a hold is NEVER displaced by a
 * claim arrival (P2.7 pins — a live, heart-beating editor must never be
 * silently stolen from; the victim learns only when its own beat fails).
 * Payload hygiene: messages carry ONLY
 * {purpose, kind, key, holderId, expiresAt} — never content, never token,
 * never field values.
 *
 * A tab that LOST the lease regains the slot on an OBSERVED free (`onFreed`):
 * a foreign release leaving the key with no live claim. Silent TTL expiry
 * travels no wire signal — the manual re-check covers that path (ADR-0004
 * P2.7 pins; never a timed auto-acquire, which could steal from a live
 * editor that a throttled browser merely silenced).
 */
export interface LeaseMessage {
    readonly purpose: "mycms-save-lease";
    readonly kind: "claim" | "release";
    readonly key: string;
    readonly holderId: string;
    /** Epoch ms — claims expire (TTL); releases are immediate. */
    readonly expiresAt: number;
}
export interface LeaseCarrier {
    post(message: LeaseMessage): void;
    onMessage(handler: (message: LeaseMessage) => void): () => void;
}
export interface SaveLease {
    /** True when WE hold the lease (fresh claim or valid renewal). */
    acquire(key: string): Promise<boolean>;
    /** Heartbeat; false = displaced/expired → caller rebaselines. */
    renew(key: string): Promise<boolean>;
    release(key: string): Promise<void>;
    /** Fires when a foreign claim displaces ours (silent steal). */
    onLost(key: string, handler: () => void): () => void;
    /**
     * Fires when an observed foreign `release` leaves the key with no live
     * foreign claim and we do not hold — the key is free for our re-acquire.
     * Silent TTL expiry fires nothing (nothing traveled the wire).
     */
    onFreed(key: string, handler: () => void): () => void;
    /** Stop listening (host teardown / tests). */
    dispose(): void;
}
export interface SaveLeaseOptions {
    readonly carrier: LeaseCarrier;
    readonly now: () => number;
    /** TTL 15 000 ms (ADR-0004 C.3 pins). */
    readonly ttlMs?: number;
    /** Heartbeat every 5 000 ms (ADR-0004 C.3 pins). */
    readonly heartbeatMs?: number;
    /** Settle window for competing fresh claims (default 150 ms). */
    readonly claimSettleMs?: number;
    readonly holderId?: string;
}
export declare const DEFAULT_LEASE_TTL_MS = 15000;
export declare const DEFAULT_LEASE_HEARTBEAT_MS = 5000;
export declare function createSaveLease(options: SaveLeaseOptions): SaveLease;

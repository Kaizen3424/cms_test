/**
 * INV-P05 — same-file predicate (L1): the save applies iff EVERY changed
 * remoteTuple(baseBlob) equals the base tuple OR is canon-equal to it; a
 * semantically drifted same-file blocks with FIELD-granularity freeze while
 * drifted other-files auto-reapply as part of the new base. (ADR-0004
 * appendix matrix rows #1/#5 + the field-level `rebase()` outcome.)
 */
export {};

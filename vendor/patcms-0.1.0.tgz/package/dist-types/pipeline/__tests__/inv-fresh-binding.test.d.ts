/**
 * INV-P08 — fresh binding (L1): challenge reads NEVER consult a cache. The
 * engine consults the injected `readFreshBlob` seam on every decision (proven
 * by call counts and a poison-vs-truth discrimination), and a full conflict
 * epoch (runSave → CAS 422 → engine) carries ZERO conditional reads.
 */
export {};

/**
 * Rebase property tests P1–P11 (ADR-0004 appendix; spec §4 L0 tier).
 *
 * Each property maps 1:1 to the ADR list: disjoint-preserve · overlap-conflict
 * · idempotence · no-change identity · unknown-preserve · unknown-loss-warn ·
 * key-order preservation · list-permutation-dirty · defaults-never-inject ·
 * no-op skip · codepoint-exact equality.
 */
export {};

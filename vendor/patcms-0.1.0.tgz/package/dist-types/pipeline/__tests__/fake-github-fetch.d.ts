/**
 * INV test harness — chaos adapters over FakeGithubServer (ADR-0005 P2).
 *
 * The server model is TRUTHFUL; all faults live here:
 * - `faults`: respond an error status WITHOUT running the handler (no state
 *   mutation — INV-P02 fault-at-stage subjects).
 * - `dropAcks`: run the handler (mutation applied) then reject the fetch —
 *   "response lost", the unknown-outcome subject of INV-P09/P10.
 * - `moveRefBefore`: simulate a concurrent foreign push just before a request
 *   matches (INV-P01 concurrent-push fixture).
 */
import type { FakeGithubSpec } from "../../backend/fake-github-server";
import { FakeGithubServer } from "../../backend/fake-github-server";
import { GithubBackend } from "../../backends/github";
import type { FetchLike } from "../../composition";
export interface FaultSpec {
    readonly method: string;
    readonly pathPattern: RegExp;
    readonly times: number;
    readonly status: number;
    /** Optional response headers — rate windows ride on 403/429 faults (INV-P11). */
    readonly headers?: Readonly<Record<string, string>>;
}
export interface DropAckSpec {
    readonly method: string;
    readonly pathPattern: RegExp;
}
export interface MoveRefSpec {
    readonly method: string;
    readonly pathPattern: RegExp;
    readonly sha: string;
}
export interface ChaosSpec {
    readonly faults?: readonly FaultSpec[];
    readonly dropAcks?: readonly DropAckSpec[];
    readonly moveRefBefore?: readonly MoveRefSpec[];
}
export interface HarnessOptions {
    readonly chaos?: ChaosSpec;
    readonly owner?: string;
    readonly repo?: string;
    readonly token?: string;
    readonly baseUrl?: string;
}
export declare function buildSpec(files: readonly [string, string][], defaultBranch?: string): Promise<FakeGithubSpec>;
/** Deterministic seeded spec: real blob/tree/commit framing throughout. */
export declare function buildSpecFromBytes(files: readonly [string, Uint8Array][], defaultBranch?: string): Promise<FakeGithubSpec>;
export interface FakeGithubHarness {
    readonly server: FakeGithubServer;
    readonly backend: GithubBackend;
    readonly fetch: FetchLike;
    /** URL prefix the adapter strips (tests may rebuild backend URLs if needed). */
    readonly prefix: string;
}
export declare function createHarness(spec: FakeGithubSpec, options?: HarnessOptions): FakeGithubHarness;
/** Baseline successful save content, reused by several invariant fixtures. */
export declare const BASE_CONTENT: readonly [string, string][];
/** Count successful ref updates (HEAD advanced exactly once subjects). */
export declare function successfulRefUpdates(server: FakeGithubServer): number;
/** Blob-sha observations: repeated equal-content creates converge (INV-P03). */
export declare function blobCreateShas(server: FakeGithubServer): string[];
export declare function patchBodies(server: FakeGithubServer): unknown[];
export declare function hasForceTrue(server: FakeGithubServer): boolean;

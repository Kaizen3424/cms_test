/**
 * INV-P06 — tuple equality (L1): `{sha, mode, type}` ALL matter. Mode-only
 * foreign drift restores OUR mode with a commit-body note; type drift blocks.
 * Neither is ever silently applied. (ADR-0004 appendix matrix rows #2/#3.)
 */
export {};

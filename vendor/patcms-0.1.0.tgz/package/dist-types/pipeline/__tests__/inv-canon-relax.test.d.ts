/**
 * INV-P07 — canon relaxation is ONE-WAY (L1): a formatting-only foreign change
 * (same parse-value, different bytes) is silently adopted as the new
 * substrate with a note; ANY semantic drift keeps field-merge — never a
 * false pass. (ADR-0004 appendix matrix row #4.)
 */
export {};

/**
 * Conflict invariant engine — FILE-level adjudication of a CAS conflict
 * (ADR-0004 appendix decision matrix; INV-P05/P06/P07/P08).
 *
 * Pure over provided git data plus one injected FRESH challenge read. The
 * engine never consults a cache (INV-P08): every content comparison goes
 * through `readFreshBlob`, whose implementation must be unconditional (no
 * If-None-Match, no memoized bytes).
 *
 * The matrix (normative — ADR-0004 appendix):
 *  1 changed, not ours            → other-file (auto-reapplied)
 *  2 sha equal, mode differs      → mode-restore (+ note)
 *  3 sha equal, type differs      → blocked: type-change
 *  4 sha differs, canon-equal     → adopt-remote (+ note)
 *  5 sha differs, canon-different → field-merge (rebase() adjudicates fields)
 *  6 our write, absent from head  → blocked: resurrect
 *  7 our delete, foreign edited   → blocked: delete-vs-edit
 *  8 our delete, foreign deleted  → reconciled
 *  9 challenge read unavailable   → blocked: unreadable
 */
import type { TreeEntryTuple } from "../backend/types";
export interface OurWrite {
    readonly bytes: Uint8Array;
    readonly mode: string;
}
export interface ConflictEngineInput {
    /** base→head file diff (head-side entries; deletions are NOT in here). */
    readonly changed: ReadonlyMap<string, TreeEntryTuple>;
    /** Head tree — detects foreign DELETIONS (resurrection, matrix #6). */
    readonly headEntries: ReadonlyMap<string, TreeEntryTuple>;
    /** Base tree entries — what our attempt was built on. */
    readonly baseEntries: ReadonlyMap<string, TreeEntryTuple>;
    readonly ourWrites: ReadonlyMap<string, OurWrite>;
    readonly ourDeletes: ReadonlySet<string>;
    /** Fresh challenge read — MUST be unconditional (INV-P08 seam). */
    readonly readFreshBlob: (path: string, tuple: TreeEntryTuple) => Promise<Uint8Array | undefined>;
    /** Raw bytes our attempt was serialized from (canon comparison source). */
    readonly baseRawBytes: (path: string) => Uint8Array | undefined;
    /** Canon predicate; default = parse-value equality (formatting-insensitive). */
    readonly canonEqual?: (baseRaw: string, remoteRaw: string) => boolean;
}
export type FileConflictVerdict = {
    readonly kind: "other-file";
} | {
    readonly kind: "clean-reapply";
} | {
    readonly kind: "adopt-remote";
} | {
    readonly kind: "mode-restore";
} | {
    readonly kind: "field-merge";
} | {
    readonly kind: "reconciled";
} | {
    readonly kind: "blocked";
    readonly reason: "type-change" | "resurrect" | "delete-vs-edit" | "unreadable";
};
export interface ConflictEngineResult {
    readonly verdicts: ReadonlyMap<string, FileConflictVerdict>;
    /** Machine-checkable commit-body warnings (mode restores, adoptions). */
    readonly notes: readonly string[];
    /**
     * INV-P05 same-file predicate: every path in our write/delete set resolves
     * to a verdict that proceeds WITHOUT field merge or block.
     */
    readonly sameFilePredicateSatisfied: boolean;
}
export declare function resolveConflictPaths(input: ConflictEngineInput): Promise<ConflictEngineResult>;

/**
 * Save coordinator — IO orchestration above the state machine (P2.5):
 * one-flight queue (INV-P04) · draft written BEFORE the first network call,
 * deleted only after the ref is observed to carry the commit (INV-P11/P10) ·
 * self-rebase when the conflict predicate is satisfied, or a clean field
 * merge exists (INV-P05; ADR-0004 "queued saves don't false-conflict after
 * own commit") · rate parking with EVENT-driven resume (INV-N01/P11) ·
 * auth pause halting the drain until `resumeAuth()` (INV-A01/A03; drafts
 * retained — ADR-0002 orthogonality) · retryable backoff cap → paused(manual)
 * (ADR-0004).
 *
 * The cross-tab lease is deliberately NOT here (ADR-0004: UX serialization
 * only — the CAS stays the sole correctness mechanism); the editor (P2.6)
 * acquires it and runs the full rebaseline (`adjudicateDraft`) on steal.
 * Progression is callback-driven (`subscribe`); the only timers are the
 * injected wakes (rate window, backoff).
 */
import type { CommitChangeSet, GitBackend } from "../backend/types";
import { BackendWriteError } from "../backend/write-errors";
import type { DraftStore, SaveDraftPayload } from "../drafts";
import type { Logger } from "../safety/logger";
import { type SaveVerdict } from "./save-driver";
import { type SaveMachineState } from "./save-machine";
export interface SaveCoordinatorOptions {
    readonly backend: GitBackend;
    readonly branch: string;
    readonly drafts: DraftStore;
    /** Epoch-ms clock (deterministic tests inject). Default Date.now. */
    readonly now?: () => number;
    /** Single scheduled wake seam (rate window + backoff). Default setTimeout. */
    readonly scheduleWake?: (waitMs: number, wake: () => void) => void;
    /** After-write failure re-probe hook (INV-A03) — forwarded to runSave. */
    readonly onAfterWriteFailure?: (error: BackendWriteError) => void;
    readonly logger?: Logger;
    /** Backoff delays for retryable failures (ms). Default [1000, 4000]. */
    readonly retryDelaysMs?: readonly number[];
    /** Auto-rebase re-entries per save (predicate satisfied / clean merge). Default 1. */
    readonly maxSelfRebases?: number;
}
export interface SaveRequest {
    readonly draftKey: string;
    readonly changes: CommitChangeSet;
    readonly message?: string;
    /**
     * Written pre-network under `draftKey` (INV-P11). Its `filePath` must be the
     * (single) write path of `changes` — v1 saves are one file; media tiles join
     * at P4 with per-tile records.
     */
    readonly draft?: SaveDraftPayload;
    /** Base sha the form was loaded against (machine bookkeeping; no extra read). */
    readonly baseSha?: string;
}
export interface CoordinatorSnapshot {
    readonly states: ReadonlyMap<string, SaveMachineState>;
}
export interface SaveCoordinator {
    /** Queues a save; resolves on its TERMINAL verdict (parked keeps pending). */
    save(request: SaveRequest): Promise<SaveVerdict>;
    /** Manual resume for a parked save (no guidance / backoff cap reached). */
    resume(draftKey: string): void;
    /** Clears the auth pause after a successful re-auth + re-probe (INV-A01). */
    resumeAuth(): void;
    /** Editor keystroke: `editing|dirty` → `dirty`; a no-op everywhere else. */
    markDirty(draftKey: string, baseSha: string): void;
    /**
     * Back to `editing` against a (new) base (ADR-0004 P2.6 pin). Legal from
     * every phase except `committing`. Used on mount, after a published/noop
     * verdict, and when the founder starts over from the latest version.
     */
    reset(draftKey: string, baseSha: string): void;
    /**
     * Abandons a save that is NOT committing: resolves `cancelled` and returns
     * the machine to `editing`. The draft is retained (crash-safety record).
     */
    cancel(draftKey: string): void;
    /** True between a 401 pause and `resumeAuth()` — save() refuses pre-network. */
    readonly authPaused: boolean;
    state(draftKey: string): SaveMachineState | undefined;
    subscribe(listener: (snapshot: CoordinatorSnapshot) => void): () => void;
}
/**
 * A second `save()` for a draftKey whose previous job is still live. Raised
 * instead of overwriting the job registration: the one-flight queue would
 * otherwise strand the first promise forever (ADR-0004 P2.6 pin).
 */
export declare class SaveInFlightError extends Error {
    readonly draftKey: string;
    constructor(draftKey: string);
}
export declare function createSaveCoordinator(options: SaveCoordinatorOptions): SaveCoordinator;

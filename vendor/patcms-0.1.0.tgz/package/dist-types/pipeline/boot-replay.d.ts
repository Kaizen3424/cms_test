/**
 * Boot replay + full-batch rebaseline — ADR-0004 §state machine + C.3 pins
 * (INV-P12 core adjudication; the browser kill-tab journey lands in e2e):
 *
 * Boot NEVER auto-writes to the remote. Each surviving draft is adjudicated
 * against a FRESH head through the invariant engine (C.2) + `rebase()`:
 *  1. `discard`   — head already carries our content (parse-equal to the form
 *                   value or byte-equal to the merged would-be result): the
 *                   save landed or converged → delete the draft.
 *  2. `offer`     — adjudication resolves to a clean apply (clean-reapply /
 *                   adopt-remote / mode-restore, or a rebase without field
 *                   overlaps): "resume your unsaved changes" — the founder
 *                   confirms; nothing writes at boot.
 *  3. `conflict`  — field-merge with real overlap, or a blocked class
 *                   (resurrect / type-change / delete-vs-edit / unreadable):
 *                   straight into the field-granularity freeze UI.
 * The SAME adjudication is the lease-steal / visibilitychange REBASELINE
 * (`queued|conflict` — never a blind re-dispatch, ADR-0004 rule).
 *
 * Uncertainty is conservative: unreadable/unshaped inputs resolve `offer`
 * (keep the founder's words; the next save runs the full fresh-binding path) —
 * never a discard, never a silent write.
 */
import type { GitBackend, TreeEntryTuple } from "../backend/types";
import type { DraftRecord, SaveDraftPayload } from "../drafts";
import { type FieldPath } from "./field-paths";
import { type FileConflictVerdict } from "./invariant-engine";
import type { ConflictMergePreview } from "./save-driver";
export type DraftAdjudication = {
    readonly kind: "discard";
    readonly reason: "already-live" | "converged";
    readonly headSha: string;
} | {
    readonly kind: "offer";
    readonly headSha: string;
    /** Merged bytes when a foreign edit was already folded in; else absent. */
    readonly mergedRaw?: string;
    /** Commit-body warnings from the engine (mode restores, adoptions). */
    readonly notes: readonly string[];
    /** Adopted foreign paths — announcements ("Kept [name]'s caption"). */
    readonly announcements: readonly FieldPath[];
} | {
    readonly kind: "conflict";
    readonly headSha: string;
    readonly details: {
        readonly baseHeadSha: string;
        readonly currentHeadSha: string;
        readonly changed: ReadonlyMap<string, TreeEntryTuple>;
    };
    readonly verdicts: ReadonlyMap<string, FileConflictVerdict>;
    /**
     * P2.9 widening (ADR-0004 appendix): the same rebase preview the save
     * path attaches, so boot conflicts feed the SAME freeze UI. Absent when
     * the merge could not be computed (blocked/unreadable classes) — the UI
     * then degrades to the banner surface.
     */
    readonly merge?: ConflictMergePreview;
};
export interface AdjudicateDraftInput {
    readonly backend: GitBackend;
    readonly branch: string;
    readonly record: DraftRecord<SaveDraftPayload>;
}
export declare function adjudicateDraft(input: AdjudicateDraftInput): Promise<DraftAdjudication>;

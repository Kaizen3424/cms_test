/**
 * Save driver — the pipeline entry point above `GitBackend.commitChanges`
 * (ADR-0005 P2 addendum; ADR-0004 laws: fresh `getRef` before EVERY save,
 * confirmation by content, drafts deleted only post-ref-verify [P2.5]).
 *
 * C.1 mechanics:
 * 1. skip-token law rejects user messages BEFORE any network call (INV-D02).
 * 2. Fresh base ref + fresh base tree — challenge decisions NEVER consult a
 *    cache (no conditional headers on driver reads — INV-P08).
 * 3. Zero-diff changesets emit ZERO writes and end as `noop` (INV-S02 C.1).
 * 4. `commitChanges` failures classify: CAS → typed conflict verdict (fresh
 *    challenge reads); auth/scope/422-validation → after-write hook fires
 *    (INV-A03 wiring completes at P2.5); network-class → verify-then-rebuild
 *    (INV-P09): fresh ref → done (content-confirmed publish, INV-P10) /
 *    rebuild with the SAME verified base / conflict.
 *
 * C.3 additions:
 * 5. RATE_LIMIT → typed `parked` verdict carrying the rate window (INV-P11/
 *    N01): the coordinator parks the queued save and resumes EVENT-driven
 *    (single scheduled wake; no guidance ⇒ manual resume, never tight-loop).
 * 6. Published-by-content completion (INV-P10): recovery compares the fresh
 *    head TREE sha against the client-computed expected tree sha (content
 *    addressing = authoritative) before the diff-level confirm. Orphan blobs
 *    are never "cleaned" — no deletion requests exist anywhere in the driver.
 * Rebuild is never a blind replay: every attempt re-enters the CAS primitive
 * whose parent chain pins the verified head.
 */
import type { CommitChangeSet, GitBackend, TreeEntryTuple } from "../backend/types";
import { BackendWriteError } from "../backend/write-errors";
import type { FieldPath } from "./field-paths";
/**
 * Rebase preview carried on a conflict verdict for the freeze UI (P2.9):
 * non-overlapping fields already merged (announcements = `warnings`), the
 * overlapping ones frozen at remote bytes until the founder decides.
 *
 * P2.9 widening (ADR-0004 appendix): `remoteRaw` carries the freshly-read
 * foreign bytes the rebase merged onto — the UI's "theirs" source and the
 * post-decision base substrate; `ourFieldPaths` lists our dirty paths minus
 * the frozen set (the "your other edits are kept" announcement input).
 */
export interface ConflictMergePreview {
    readonly path: string;
    readonly mergedRaw: string;
    readonly frozenFieldPaths: readonly FieldPath[];
    /** Adopted foreign paths — "Kept [name]'s caption" announcements. */
    readonly warnings: readonly FieldPath[];
    /** Machine-checkable commit-body warnings (mode restores, adoptions). */
    readonly engineNotes: readonly string[];
    /** Fresh foreign bytes at decision time (theirs; also the new base raw). */
    readonly remoteRaw: string;
    /** Our dirty paths that did NOT overlap (informational). */
    readonly ourFieldPaths: readonly FieldPath[];
}
/**
 * P2.9 widening (ADR-0004 appendix): present on `published`/`noop` ONLY when
 * the controller landed bytes OTHER than what the editor composed (the disjoint
 * auto-merge replaces the write bytes with the merged result). The editor
 * adopts the reconciled bytes as its post-publish base and replays keystrokes
 * typed during the save onto them — without it, the next save would silently
 * revert the partner's change (base mismatch).
 */
export interface SaveReconciliation {
    /** The bytes actually committed (or carried by the foreign head on noop). */
    readonly reconciledRaw: string;
    /** Commit carrying them: the published sha, or the foreign head on noop. */
    readonly reconciledSha: string;
}
export interface SaveConflictDetails {
    /** Head the failed attempt was pinned to. */
    readonly baseHeadSha: string;
    /** Freshly read head at decision time ("" only when the read itself failed). */
    readonly currentHeadSha: string;
    /** Fresh base→head changed files (INV-P05 tuple domain, C.2 engine input). */
    readonly changed: ReadonlyMap<string, TreeEntryTuple>;
    /** Freeze-UI fields — controller-enriched; the driver never fills these. */
    readonly merge?: ConflictMergePreview;
    readonly verdicts?: ReadonlyMap<string, import("./invariant-engine").FileConflictVerdict>;
}
export type SaveVerdict = {
    readonly kind: "published";
    readonly commitSha: string;
    readonly treeSha?: string;
    /** P2.9: present when the committed bytes differ from the editor's own. */
    readonly reconciliation?: SaveReconciliation;
} | {
    readonly kind: "noop";
    readonly reconciliation?: SaveReconciliation;
} | {
    readonly kind: "conflict";
    readonly details: SaveConflictDetails;
}
/**
 * RATE_LIMIT with the parsed window (INV-P11): `waitMs === null` means no
 * usable guidance — the coordinator parks for MANUAL resume instead of
 * tight-looping on a null countdown.
 */
 | {
    readonly kind: "parked";
    readonly waitMs: number | null;
    readonly error: BackendWriteError;
}
/** Terminal for this driver call; surfaces through the failure screens. */
 | {
    readonly kind: "failed";
    readonly error: BackendWriteError;
}
/**
 * The editor abandoned a non-committing save (navigation/teardown). Never
 * produced by the driver; the coordinator resolves its own pending promise
 * with it so an abandoned job settles instead of hanging (ADR-0004 P2.6 pin).
 */
 | {
    readonly kind: "cancelled";
};
export interface SaveDriverInput {
    readonly backend: GitBackend;
    readonly branch: string;
    readonly changes: CommitChangeSet;
    /** User-editable message; skip-token carrying input is rejected (INV-D02). */
    readonly message?: string;
    /** After-write failure hook (401/403/422-class codes) — admin re-probes (INV-A03). */
    readonly onAfterWriteFailure?: (error: BackendWriteError) => void;
    /** Unknown-outcome verify-then-rebuild budget (INV-P09). Default 2. */
    readonly maxRebuilds?: number;
    /** Epoch-ms clock for rate windows (deterministic tests inject). */
    readonly now?: () => number;
}
export declare function runSave(input: SaveDriverInput): Promise<SaveVerdict>;

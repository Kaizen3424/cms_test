/**
 * `fieldPath` + dirty-set machinery (ADR-0004 appendix).
 *
 * A fieldPath is an ordered segment list — object KEY or list INDEX per step.
 * The appendix defines the granularity both the dirty computation and the
 * rebase adjudication obey:
 * - records recuse (per-key paths),
 * - lists with equal length compare per index,
 * - lists with differing length are ONE whole-list unit,
 * - leaves compare via `fieldEquals`.
 *
 * `diffPaths(next, base)` is the single source of that granularity: the editor
 * derives our dirty set with it; the engine derives the foreign set with it.
 */
export type FieldPathSegment = string | number;
export type FieldPath = readonly FieldPathSegment[];
/** Stable canonical key for a path (Set/Map plumbing). */
export declare function fieldPathKey(path: FieldPath): string;
export declare function equalsFieldPath(left: FieldPath, right: FieldPath): boolean;
/** True iff `ancestor` is strictly above `path` on the same branch. */
export declare function isAncestorFieldPath(ancestor: FieldPath, path: FieldPath): boolean;
/** Same node, ancestor, or descendant — the overlap rule's relation. */
export declare function relatedFieldPaths(left: FieldPath, right: FieldPath): boolean;
/** Minimal common node of two related paths (conflict reporting granularity). */
export declare function commonAncestorFieldPath(left: FieldPath, right: FieldPath): FieldPath;
export interface ResolvedFieldValue {
    readonly found: boolean;
    readonly value: unknown;
}
/** Reads `path` inside a parsed JSON-ish tree; `found:false` means absent. */
export declare function readAtFieldPath(root: unknown, path: FieldPath): ResolvedFieldValue;
/**
 * Dirty-field paths between a NEXT value tree and its BASE — the ADR
 * granularity (objects recuse; equal-length lists per index; length-differing
 * lists whole-list; leaves via `fieldEquals`; added/removed keys emitted as
 * their own paths). Non-record roots fall through to a leaf comparison.
 */
export declare function diffPaths(next: unknown, base: unknown, path?: FieldPath): FieldPath[];
/** Convenience for the editor + property tests: dirty = diffPaths(form, base). */
export declare function computeDirtyPaths(formValue: unknown, oldBase: unknown): FieldPath[];
export type FieldPathWriteResult = {
    readonly ok: true;
    readonly tree: unknown;
} | {
    readonly ok: false;
    readonly issue: FieldPathWriteIssue;
};
export interface FieldPathWriteIssue {
    readonly code: "ROOT_PATH" | "SPLICE_GAP";
    readonly detail: string;
}
/**
 * Writes `value` at `path` inside a deep clone of `tree`, creating intermediate
 * containers when genuinely new (a record key creates an object or a list
 * depending on whether the NEXT segment is an index). `path: []` is refused —
 * the root is not a field.
 */
export declare function writeAtFieldPath(tree: unknown, path: FieldPath, value: unknown): FieldPathWriteResult;
/**
 * Removes the key at `path` from a deep clone of `tree`. Deleting an absent key
 * is already the target state — a no-op success. List-ITEM deletion is refused
 * (`SPLICE_GAP`): index shifts would silently reorder; a list removal is a
 * whole-list write decided at the list path. `path: []` is refused.
 */
export declare function deleteAtFieldPath(tree: unknown, path: FieldPath): FieldPathWriteResult;

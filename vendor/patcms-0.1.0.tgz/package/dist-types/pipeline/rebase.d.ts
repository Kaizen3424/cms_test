/**
 * `rebase()` — the FIELD-granular merge (ADR-0004 + appendix; INV-P05/P07/P08
 * downstream). Pure, Result-shaped, never throws.
 *
 * Laws (appendix is normative):
 * - dirty is decided in the VALUE domain (`diffPaths`/`fieldEquals`), the merge
 *   is performed in the RAW domain (splice into a copy of `parse(newBaseRaw)`,
 *   canonical print; verbatim bytes when nothing splices),
 * - overlap ⇒ CONFLICT at the minimal common node — never a silent win,
 * - unknowns come only from the new raw; old unknowns never resurrect,
 * - adopted foreign changes (incl. deletions, unknown loss) warn — "auto-merge
 *   with announcements",
 * - `oldBase` is verified against `parse(oldRaw)` (STALE_BASE guard).
 */
import type { JsonValue } from "../safety/untrusted-json";
import { type FieldPath } from "./field-paths";
export type RebaseIssueCode = "INVALID_JSON" | "TOO_LARGE" | "TOO_DEEP" | "TOO_MANY_ITEMS" | "STALE_BASE" | "ROOT_SHAPE" | "SPLICE_GAP";
export interface RebaseIssue {
    readonly code: RebaseIssueCode;
    readonly path?: string;
    readonly detail?: string;
}
export interface RebaseSuccess {
    readonly ok: true;
    readonly mergedRaw: string;
    /** Frozen fields — user decides; remote bytes kept until then. */
    readonly conflicts: readonly FieldPath[];
    /** Silently adopted foreign changes (announcements), incl. deletions. */
    readonly warnings: readonly FieldPath[];
}
export type RebaseResult = RebaseSuccess | {
    readonly ok: false;
    readonly issues: readonly RebaseIssue[];
};
export interface RebaseInput {
    readonly formValue: JsonValue;
    readonly dirtyPaths: ReadonlySet<FieldPath>;
    /** Full parsed value of `oldRaw` (verified inside — STALE_BASE guard). */
    readonly oldBase: JsonValue;
    readonly oldRaw: string;
    readonly newBaseRaw: string;
}
export declare function rebase(input: RebaseInput): RebaseResult;

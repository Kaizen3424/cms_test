/**
 * Git SHA-1 framing — ADR-0005 P2 addendum.
 *
 * WebCrypto (`crypto.subtle.digest`) so browser and Node 22 produce identical
 * results with zero dependencies. The framings here are pinned by tests against
 * the yve fixture manifest (computed independently by `sync-yve-fixtures.mjs`
 * with `node:crypto`) and by NIST vectors, so a WebCrypto regression cannot
 * silently diverge from real git.
 */
/** Strict hex decode; undefined on malformed input (never silently corrupt). */
export declare function hexDecodeStrict(value: string): Uint8Array | undefined;
/** SHA-1 hex digest over exact bytes. */
export declare function sha1Hex(bytes: Uint8Array): Promise<string>;
/** Git blob SHA-1: sha1("blob {byteLength}\\0" + bytes). */
export declare function gitBlobSha(bytes: Uint8Array): Promise<string>;
/** Flat tree entry: a repo-relative POSIX path with its git mode/type/sha. */
export interface GitTreeEntry {
    readonly path: string;
    readonly mode: string;
    readonly type: string;
    readonly sha: string;
    readonly size?: number;
}
/**
 * Git tree SHA-1 from a FLAT path list (recursive framing): directories are
 * hashed depth-first, names sort per-directory, and subtree SHAs hex-decode
 * into the parent frame. Equal file maps therefore hash to equal tree SHAs
 * (content addressing) — the property the zero-diff skip (INV-S02 C.1 scope)
 * and idempotent retries (INV-P03) rely on.
 */
export declare function gitTreeSha(entries: readonly GitTreeEntry[]): Promise<string>;
/** Deterministic fixture commit framing — equal content ⇒ equal sha (INV-P03). */
export interface CanonicalCommitInput {
    readonly treeSha: string;
    readonly parentShas: readonly string[];
    readonly message: string;
}
/** Git commit SHA-1 with a FIXED author/committer (fixture determinism). */
export declare function gitCommitShaCanonical(input: CanonicalCommitInput): Promise<string>;

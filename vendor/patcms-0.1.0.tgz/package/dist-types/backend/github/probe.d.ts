/**
 * Login-time capability probe — INV-A03 partial (P1).
 *
 * Reads rate_limit + repo + protection-admin + check-runs. Checks-read may be
 * missing/forbidden without blocking login (advisory). The probe result is
 * returned to the caller and NEVER persisted (only the token may be stored).
 */
import type { CapabilityProbeResult } from "../../auth/types";
import type { FetchLike } from "../../composition";
export interface GithubProbeOptions {
    readonly owner: string;
    readonly repo: string;
    readonly token: string;
    readonly branch: string;
    readonly fetch: FetchLike;
    readonly baseUrl?: string;
}
export declare function probeGithubCapabilities(options: GithubProbeOptions): Promise<CapabilityProbeResult>;

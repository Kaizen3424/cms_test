/**
 * FakeGithubServer — the reference GitHub git-data model (ADR-0005 P2 addendum
 * + ADR-0001/0009 posture: every fake stays behind the SAME contract suite).
 *
 * HTTP-shaped and zero-dependency: adapters map transport frames onto
 * `handle()` and JSON responses out. Core INV tests drive it through a
 * `FetchLike` adapter; the playground's MSW FakeGithub delegates to it so BOTH
 * harnesses share one source of framing/CAS/permission rules.
 *
 * Truthful semantics (chaos knobs live OUTSIDE this file, in harness adapters):
 * - Branch is always a path parameter (INV-P14 law).
 * - PATCH ref is fast-forward-only: the new commit must name the current head
 *   as a parent; non-FF ⇒ 422 "Update is not a fast forward" (INV-P01). A
 *   `force: true` body IS honored like real GitHub — but every request lands
 *   in the request log, so the FF-only invariant greps for violations there.
 * - Blobs/trees/commits are content-addressed: equal payload ⇒ equal sha
 *   (INV-P03 idempotent-retry convergence).
 * - Trees accept `base_tree` + changed paths only (deletes = `sha: null`),
 *   and a no-op overlay reproduces the base tree sha exactly (INV-S02 C.1).
 */
import type { CheckRunConclusion, CheckRunStatus, CommitStatusState } from "./types";
import { classifyWriteResponse, networkWriteError } from "./write-errors";
export interface FakeGithubSpec {
    readonly defaultBranch: string;
    readonly headSha: string;
    readonly treeSha: string;
    readonly files: ReadonlyMap<string, {
        readonly sha: string;
        readonly bytes: Uint8Array;
    }>;
}
/** Test input for `setCheckRuns` — ids/names default deterministically. */
export interface FakeCheckRunInput {
    readonly id?: number;
    readonly name?: string;
    readonly status?: CheckRunStatus;
    readonly conclusion?: CheckRunConclusion | null;
    readonly detailsUrl?: string;
}
export interface FakeCommitStatusInput {
    readonly context: string;
    readonly state: CommitStatusState;
    readonly targetUrl?: string;
}
export interface FakeRequest {
    readonly method: string;
    /** Repo-relative path (no `/repos/{owner}/{repo}` prefix), queryless. */
    readonly path: string;
    /** Lower-cased header lookup (optional — GETs need If-None-Match never here). */
    readonly headers?: Readonly<Record<string, string>>;
    /** Parsed JSON body when present; adapter owns parsing (that IS transport). */
    readonly body?: unknown;
}
export interface FakeResponse {
    readonly status: number;
    readonly headers?: Readonly<Record<string, string>>;
    readonly json?: unknown;
}
/** Every request with its parsed mutation body — request-log assertions (INV-P01). */
export interface FakeRequestLogEvent {
    readonly method: string;
    readonly path: string;
    readonly status: number;
    readonly body?: unknown;
    /** Safe request headers (the harness strips Authorization before logging). */
    readonly headers?: Readonly<Record<string, string>>;
}
export declare class FakeGithubServer {
    #private;
    readonly log: FakeRequestLogEvent[];
    constructor(spec: FakeGithubSpec);
    /** Current head (40-hex) for a branch, or undefined when unknown. */
    ref(branch: string): string | undefined;
    /**
     * Contents-route backing for harness adapters (path → bytes via the branch
     * head's tree). Returns undefined for unknown paths — 404 shaping is the
     * adapter's transport concern.
     */
    contents(branch: string, path: string): {
        readonly bytes: Uint8Array;
        readonly sha: string;
    } | undefined;
    /** Blob byte size by sha (tree responses add `size` at the adapter layer). */
    blobSize(sha: string): number | undefined;
    /** Harness hook: simulate a concurrent push (satisfies INV-P01 fixtures). */
    setRef(branch: string, sha: string): void;
    /**
     * Attach/replace check runs for a commit (branch heads resolve through the
     * same route). An empty list means "no run has landed" (grace subject).
     */
    setCheckRuns(sha: string, runs: readonly FakeCheckRunInput[]): void;
    /** Attach/replace commit statuses (the `contexts[]` fallback source). */
    setStatuses(sha: string, statuses: readonly FakeCommitStatusInput[]): void;
    /** Parsed commit count AFTER a save (INV-P02 "exactly one commit"). */
    commitCount(): number;
    handle(request: FakeRequest): Promise<FakeResponse>;
    /** Bytes seeded from the fixture spec (blob reads beyond created blobs). */
    specBytes(sha: string): Uint8Array | undefined;
}
export declare function notFoundResponse(): FakeResponse;
export { classifyWriteResponse, networkWriteError };

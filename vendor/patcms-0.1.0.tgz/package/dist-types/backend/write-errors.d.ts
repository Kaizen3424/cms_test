/**
 * Typed write errors (ADR-0005 P2 addendum). Status + body-CLASS mapping only:
 * response bodies never leak into messages (read-path precedent), and the admin
 * message map — never inline prose — renders founder-friendly screens (INV-A02).
 */
export type WriteErrorCode = 
/** FF guard tripped: ref moved / update is not a fast forward (INV-P01). */
"CAS_CONFLICT"
/** Other 422 class: oversize tree, missing blob sha, malformed parents… */
 | "VALIDATION" | "AUTH_EXPIRED" | "SCOPE" | "NOT_FOUND" | "RATE_LIMIT" | "NETWORK" | "TREE_TRUNCATED" | "UNKNOWN";
export declare class BackendWriteError extends Error {
    readonly name = "BackendWriteError";
    readonly code: WriteErrorCode;
    readonly status?: number;
    /** Retry-After seconds/header value carried verbatim for the rate policy. */
    readonly retryAfter?: string;
    /** X-RateLimit-Reset epoch seconds (primary exhaustion → reset countdown, INV-N01). */
    readonly resetAt?: string;
    constructor(code: WriteErrorCode, message: string, options?: {
        status?: number;
        retryAfter?: string;
        resetAt?: string;
    });
}
export declare function isBackendWriteError(error: unknown): error is BackendWriteError;
/** Supplementary facts the classifier may consult (headers accessor-shaped). */
export interface WriteFailureHints {
    readonly status: number;
    readonly headers: {
        get(name: string): string | null;
    };
    /** Response body text — INSPECTED for error-class keywords only, never stored. */
    readonly bodyText: string;
}
/**
 * transport-failure → typed BackendWriteError classification (ADR-0005 P2).
 * The caller has already read the body ONCE (single response consumption);
 * this function reads no network state.
 */
export declare function classifyWriteResponse(hints: WriteFailureHints): BackendWriteError;
/** Network-layer failure → typed error (fetch threw / response dropped). */
export declare function networkWriteError(cause: unknown): BackendWriteError;
/** Recovery classification for unknown outcomes (INV-P09 vocabulary). */
export type ReverifyOutcome = "done" | "rebuild" | "conflict";

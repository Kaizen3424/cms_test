/**
 * @mycms/core public entry — ADR-0001 (one composition root) + ADR-0010 §1
 * (naming appears here + docs headers only).
 *
 * P0 state: laws encoded as seams (interfaces, DI stubs, runner, masked
 * logger). Mechanisms land per the ADR roster: config P1.1, fields P1.2,
 * backend reads P1.4, pipeline P2, drafts P2.5, web adapters P2.5.
 */
export type { AuthKind, AuthProvider, CapabilityProbeResult, CapabilityStatus, PatProviderOptions, ProbeErrorCode, RateLimitSnapshot, SignInOptions, TokenStore, } from "./auth";
export { CapabilityProbeError, MemoryTokenStore, PatProvider, } from "./auth";
export type { ContractCheck, ContractContext, ContractFailure, ContractReport, } from "./backend/contract-suite";
export { BLOB_READ_CHECK, CORE_CONTRACT_SUITE, defineContractSuite, runContractSuite, SHAPE_CHECK, STATUS_READ_CHECK, WRITE_CAS_CHECK, WRITE_COMMIT_CHECK, } from "./backend/contract-suite";
export type { ReadErrorCode } from "./backend/errors";
export { BackendReadError, isBackendReadError } from "./backend/errors";
export type { FakeCheckRunInput, FakeCommitStatusInput, FakeGithubSpec, FakeRequest, FakeRequestLogEvent, FakeResponse, } from "./backend/fake-github-server";
export { FakeGithubServer } from "./backend/fake-github-server";
export type { GitTreeEntry } from "./backend/git-sha";
export { gitBlobSha, gitCommitShaCanonical, gitTreeSha, sha1Hex } from "./backend/git-sha";
export type { GithubProbeOptions } from "./backend/github/probe";
export { probeGithubCapabilities } from "./backend/github/probe";
export type { ReadTreeLike, Result, TreeTruncationIssue } from "./backend/guards";
export { assertNotTruncated } from "./backend/guards";
export type { CheckRunConclusion, CheckRunStatus, CheckRunSummary, CheckRunsRead, CommitChangeSet, CommitResult, CommitStatusesRead, CommitStatusState, CommitStatusSummary, FileRead, FileWrite, GitBackend, GitBackendCapabilities, ReadFileOptions, ReadFileResult, ReadTreeOptions, ReadTreeResult, Ref, RefObject, TreeEntryTuple, TreeRead, } from "./backend/types";
export type { WriteErrorCode } from "./backend/write-errors";
export { BackendWriteError, classifyWriteResponse, isBackendWriteError, networkWriteError, } from "./backend/write-errors";
export type { GithubBackendOptions, RecordedInteraction, RecordedRequest, RecordedResponse, RecordedTape, RecordedTapeMeta, ReplayFetch, ReplayFetchOptions, } from "./backends/github";
export { buildMatchKey, canonicalizeJson, createReplayFetch, encodeBranch, GithubBackend, normalizeBodyString, normalizeRequestPath, } from "./backends/github";
export type { FixtureFile, FixtureRepoSpec } from "./backends/reference-fixture-backend";
export { ContractStubNotImplementedError, FixtureBackend, textFixtureFile, } from "./backends/reference-fixture-backend";
export type { FileCacheEntry, SnapshotRef, TreeCacheEntry } from "./cache";
export { SnapshotStore } from "./cache";
export type { CreateMyCMSDeps, FetchLike, FetchRequestInitLike, FetchResponseLike, MyCMSInstance, } from "./composition";
export { createMyCMS } from "./composition";
export type { AdminConfig, CollectionDefinition, CollectionDescriptor, CollectionDivider, CollectionDividerDescriptor, ConfigDefinition, ConfigIssue, ConfigOptions, FileDefinition, FileDescriptor, FileOptions, FilesCollectionDefinition, FilesCollectionDescriptor, FilesCollectionOptions, FolderCollectionDefinition, FolderCollectionDescriptor, FolderCollectionOptions, MediaFolders, ViewGroup, } from "./config";
export { CONFIG_SCHEMA_VERSION, ConfigValidationError, collectionDivider, defineCollection, defineConfig, defineFile, defineFiles, fieldDescriptorSchema, parseAdminConfig, safeParseAdminConfig, toAdminConfig, } from "./config";
export type { DraftKey, DraftRecord, DraftStore, SaveDraftPayload } from "./drafts";
export type { BaseFieldDescriptor, BaseFieldMeta, BaseFieldOptions, BooleanFieldDescriptor, BooleanFieldMeta, BooleanFieldOptions, DatetimeFieldDescriptor, DatetimeFieldMeta, DatetimeFieldOptions, DividerDeclaration, DividerFieldDescriptor, EntryValidationOptions, EntryValidationResult, FieldDescriptor, FieldMeta, FieldTypeName, FieldWidth, HiddenFieldDescriptor, HiddenFieldMeta, HiddenFieldOptions, ImageFieldDescriptor, ImageFieldMeta, ImageFieldOptions, ListFieldDescriptor, ListFieldMeta, ListFieldOptions, NamedFieldSchema, NumberFieldDescriptor, NumberFieldMeta, NumberFieldOptions, ObjectFieldDescriptor, ObjectFieldMeta, ObjectFieldOptions, ParsedEntry, ParseEntryOptions, ParseIssue, ParseIssueCode, RelationFieldDescriptor, RelationFieldMeta, RelationFieldOptions, RelationServices, SelectFieldDescriptor, SelectFieldMeta, SelectFieldOptions, SelectOption, SlugFieldDescriptor, SlugFieldMeta, SlugFieldOptions, StringFieldDescriptor, StringFieldMeta, StringFieldOptions, StringFormat, TextFieldDescriptor, TextFieldMeta, TextFieldOptions, } from "./fields";
export { boolean, CMS_META_KEY, datetime, defineField, divider, getFieldMeta, hidden, image, list, mergeUntouched, number, object, parseEntry, relation, select, setFieldMeta, slug, string, text, unwrapFieldSchema, validateEntryForSave, } from "./fields";
export type { DeleteCheckResult, MediaBudget, ReferenceLocation, ReferenceQuery, RestoreChangesResult, SearchableEntry, StagedMediaTileRecord, } from "./media";
export { CLIENT_BLOCK_BYTES, calculateMediaBudget, canDeleteMedia, createRestoreChanges, createTrashChanges, findReferences, isUploadSizeBlocked, publicPathToRepoPath, repoPathToPublicPath, resolveMediaFolders, restoreMediaPath, TRASH_PREFIX, trashMediaPath, WARNING_THRESHOLD_BYTES, WARNING_THRESHOLD_COUNT, } from "./media";
export type { AdjudicateDraftInput, CommitMessageVerdict, ConcurrencyLimiter, ConflictEngineInput, ConflictEngineResult, ConflictMergePreview, CoordinatorSnapshot, DraftAdjudication, FieldPath, FieldPathSegment, FieldPathWriteIssue, FieldPathWriteResult, FileConflictVerdict, LeaseCarrier, LeaseMessage, OneFlightQueue, OurWrite, RateDescriptor, RebaseInput, RebaseIssue, RebaseIssueCode, RebaseResult, RebaseSuccess, SaveConflictDetails, SaveCoordinator, SaveCoordinatorOptions, SaveDriverInput, SaveLease, SaveLeaseOptions, SaveMachineEvent, SaveMachineState, SavePauseReason, SavePhase, SaveReconciliation, SaveRequest, SaveVerdict, } from "./pipeline";
export { adjudicateDraft, commonAncestorFieldPath, composeCommitMessage, computeDirtyPaths, containsSkipToken, createConcurrencyLimiter, createOneFlightQueue, createRateResume, createSaveCoordinator, createSaveLease, DEFAULT_LEASE_HEARTBEAT_MS, DEFAULT_LEASE_TTL_MS, deleteAtFieldPath, describeRatePause, diffPaths, equalsFieldPath, fieldEquals, fieldPathKey, isAncestorFieldPath, isRetryableWriteCode, isZeroDiffChangeSet, parseRateWindowReset, parseRetryAfter, readAtFieldPath, rebase, relatedFieldPaths, resolveConflictPaths, runSave, SAVE_PHASE_ORDER, SaveInFlightError, transitionSaveState, writeAtFieldPath, } from "./pipeline";
export type { JsonPrimitive, JsonValue, MoneyFormatOptions, SafePathFailureCode, SafePathOptions, SafePathResult, SafeUrlFailureCode, SafeUrlOptions, SafeUrlResult, SortDirection, TemplateValues, UntrustedJsonFailureCode, UntrustedJsonIssue, UntrustedJsonOptions, UntrustedJsonResult, } from "./safety";
export { compareNumbers, compareText, compareValues, createLogger, createTextCollator, DEFAULT_LOCALE, decodeBase64, decodeUtf8, deriveSlug, encodeBase64, encodeUtf8, formatFriendlyDate, formatMoney, formatRelativeTime, isSafePath, isSafeUrl, mustacheLite, parseUntrustedJson, readPath, safePath, safeUrl, sortBy, UNTRUSTED_JSON_LIMITS, utf8ByteLength, } from "./safety";
export type { Logger, LogLevel, LogRecord } from "./safety/logger";
export type { ComposedEntryDocument, ComposeEntryDocumentInput, JsonDocument, NewlineStyle, ParseJsonDocumentResult, } from "./serialization";
export { canonicalJson, composeEntryDocument, detectNewline, documentsCanonicallyEqual, jsonEqual, normalizeNewlines, parseJsonDocument, serializeDocument, } from "./serialization";
export type { DeployStatusCause, DeployStatusKind, DeployStatusSnapshot, StatusDecision, StatusReads, StatusTiming, StatusWatcher, StatusWatcherOptions, } from "./status";
export { classifyCheckRuns, classifyCommitStatuses, createStatusReads, createStatusWatcher, DEFAULT_STATUS_TIMING, decideStatus, } from "./status";
export type { WebKeyValueStore } from "./web";
export { clearIdbDraftStore, createIdbDraftStore } from "./web";

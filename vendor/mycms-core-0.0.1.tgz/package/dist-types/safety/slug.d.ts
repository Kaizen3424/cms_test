/**
 * Slug is VIRTUAL: derived from the entry filename, never stored in JSON.
 * `src/content/products/iris-no-7.json` → `iris-no-7`.
 */
export declare function deriveSlug(filePath: string): string | null;

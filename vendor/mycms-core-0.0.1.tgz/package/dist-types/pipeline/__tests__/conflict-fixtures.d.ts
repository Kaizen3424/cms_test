/**
 * Conflict-engine INV fixtures — harness plumbing shared by INV-P05/P06/P07/P08.
 * Foreign commits are pushed through the REAL transport adapter (harness.fetch),
 * so every assertion observes what GithubBackend observes.
 */
import type { TreeEntryTuple } from "../../backend/types";
import type { ConflictEngineInput, OurWrite } from "../invariant-engine";
import type { FakeGithubHarness } from "./fake-github-fetch";
export declare const BRANCH = "fixture-branch";
/** Creates a foreign blob through the real transport — tree entries need an existing sha. */
export declare function createForeignBlob(harness: FakeGithubHarness, text: string): Promise<string>;
export interface ForeignTreeEntry {
    readonly path: string;
    /** Existing blob sha; `null` deletes the path. */
    readonly sha: string | null;
    readonly mode?: string;
    readonly type?: string;
}
export interface ForeignCommit {
    /** New commit sha. */
    readonly commitSha: string;
    readonly treeSha: string;
}
/**
 * Creates a foreign commit ON TOP of the CURRENT branch head through the real
 * transport (tree with base_tree → commit). The ref is NOT moved unless
 * `updateRef` — P08's conflict epoch needs the commit to exist while the ref
 * still names the base, so `moveRefBefore` can move it mid-save.
 */
export declare function createForeignCommit(harness: FakeGithubHarness, entries: readonly ForeignTreeEntry[], options?: {
    readonly message?: string;
    readonly updateRef?: boolean;
}): Promise<ForeignCommit>;
/** `createForeignCommit` + the FF ref update (the ordinary foreign push). */
export declare function pushForeignCommit(harness: FakeGithubHarness, entries: readonly ForeignTreeEntry[], message?: string): Promise<ForeignCommit>;
/** Flat tuple map at a commit (INV-N02 law: callers own truncation asserts upstream). */
export declare function treeEntriesAt(harness: FakeGithubHarness, commitSha: string): Promise<ReadonlyMap<string, TreeEntryTuple>>;
/** Blob bytes at an arbitrary commit (tree walk → git-blobs read). */
export declare function blobBytesAt(harness: FakeGithubHarness, commitSha: string, path: string): Promise<Uint8Array>;
/**
 * The INV-P08 seam: challenge reads go through the backend WITHOUT an ETag —
 * unconditional by construction (the request log can prove it). Any read
 * failure resolves `undefined` — the engine's conservative `blocked:
 * unreadable` (matrix #9), never a thrown crash mid-adjudication.
 */
export declare function makeReadFreshBlob(harness: FakeGithubHarness): ConflictEngineInput["readFreshBlob"];
export interface ConflictInputsOptions {
    readonly baseSha: string;
    readonly headSha: string;
    readonly ourWrites?: ReadonlyMap<string, OurWrite>;
    readonly ourDeletes?: ReadonlySet<string>;
    /** Raw bytes our attempt serialized from (the base commit's files). */
    readonly baseRaw?: ReadonlyMap<string, Uint8Array>;
}
export declare function conflictInputs(harness: FakeGithubHarness, options: ConflictInputsOptions): Promise<ConflictEngineInput>;
/** baseRawBytes provider over the files we seeded (the attempt's raw source). */
export declare function baseRawBytesFrom(files: readonly [string, string][]): Map<string, Uint8Array>;
